#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include "check.h"
#include "calequation.h"
#include "math.h"
#include "calmatrix.h"
#include "stdlib.h"
#include "math.h"
#include "calcomplex.h"//weeny

//#include "stdio.h"
using namespace std;

int ck=0;
//ck=1; �ڽⷽ������������з���δ�������
//ck=2; �������벻����Ҫ��
//ck=3; ��һԪ�������Ĺ����з���δ�������
//ck=4; ����ȱ�ٵȺŻ��ұ߲�Ϊ��
//ck=5; �����г��ַǷ��ַ�
//ck=6; ������ȱ��ָ��
//ck=7; ���ַǷ�ʹ�õ������
//ck=8; �����435
//ck=9; �����453
//CK=10; �����468
//ck=11; ��ߴ�ϵ������Ϊ0
//ck=12; �ڿ��������з���δ�������
//ck=13; �����622
//ck=14; �����631
int agaus(double a[],double b[],int n)
{ 
	int *js,l,k,i,j,is,p,q;
	double d,t;
	js=(int*)malloc(n*sizeof(int));
	l=1;
	for (k=0;k<=n-2;k++)
	{ d=0.0;
	for (i=k;i<=n-1;i++)
		for (j=k;j<=n-1;j++)
		{ t=fabs(a[i*n+j]);
	if (t>d) { d=t; js[k]=j; is=i;}
		}
		if (d+1.0==1.0) l=0;
		else
		{ if (js[k]!=k)
		for (i=0;i<=n-1;i++)
		{ p=i*n+k; q=i*n+js[k];
		t=a[p]; a[p]=a[q]; a[q]=t;
		}
		if (is!=k)
		{ for (j=k;j<=n-1;j++)
		{ p=k*n+j; q=is*n+j;
		t=a[p]; a[p]=a[q]; a[q]=t;
		}
		t=b[k]; b[k]=b[is]; b[is]=t;
		}
		}
		if (l==0)
		{ free(js); 
		if(ck==0)
			ck=1;
		return(0);
		}
		d=a[k*n+k];
		for (j=k+1;j<=n-1;j++)
		{ p=k*n+j; a[p]=a[p]/d;}
		b[k]=b[k]/d;
		for (i=k+1;i<=n-1;i++)
		{ for (j=k+1;j<=n-1;j++)
		{ p=i*n+j;
		a[p]=a[p]-a[i*n+k]*a[k*n+j];
		}
		b[i]=b[i]-a[i*n+k]*b[k];
		}
	}
	d=a[(n-1)*n+n-1];
	if (fabs(d)+1.0==1.0)
	{ free(js); 
	if(ck==0)
		ck=1;
	return(0);
	}
	b[n-1]=b[n-1]/d;
	for (i=n-2;i>=0;i--)
	{ t=0.0;
	for (j=i+1;j<=n-1;j++)
		t=t+a[i*n+j]*b[j];
	b[i]=b[i]-t;
	}
	js[n-1]=n-1;
	for (k=n-1;k>=0;k--)
		if (js[k]!=k)
		{ t=b[k]; b[k]=b[js[k]]; b[js[k]]=t;}
		free(js);
		return(1);
}

int cal_equations(string coff, string b, string& res)
{
	int a1, a2, b1, b2;
	int sta1=check_matrix(coff, a1, a2);
	int sta2=check_matrix(b, b1, b2);
	if(sta1 && sta2 && (a1==a2) && (a1==b1) && (b2==1))
	{
		istringstream iss2(b);
		istringstream iss1(coff);
		double* cof=new double[a1*a2];
		double* bb=new double[b1];
		for(int i=0; i<a1*a2; i++)
		{
			iss1>>cof[i];
		}
		for(int i=0; i<b1; i++)
		{
			iss2>>bb[i];
		}
		int sta3=agaus(cof, bb, a1);
		if(sta3==0)
		{
			delete[] cof;
			delete[] bb;
			if(ck==0)
				ck=1;
			return 0;
		}
		else
		{
			ostringstream oss;
			for(int i=0; i<a1; i++)
			{
				oss<<"X("<<i<<")="<<bb[i]<<"\r\n";
			}
			res=oss.str();
			delete[] cof;
			delete[] bb;
			return 1;
		}
	}
	else 
	{
		if(ck==0)
			ck=2;
		return 0;
	}
}


int chhqr(double a[],int n,double u[],double v[],double eps,int jt)
{
	int m,it,i,j,k,l,ii,jj,kk,ll;
	double b,c,w,g,xy,p,q,r,x,s,e,f,z,y;
	it=0; m=n;
	while (m!=0)
	{ l=m-1;
	while ((l>0)&&(fabs(a[l*n+l-1])>eps*
		(fabs(a[(l-1)*n+l-1])+fabs(a[l*n+l])))) l=l-1;
	ii=(m-1)*n+m-1; jj=(m-1)*n+m-2;
	kk=(m-2)*n+m-1; ll=(m-2)*n+m-2;
	if (l==m-1)
	{ u[m-1]=a[(m-1)*n+m-1]; v[m-1]=0.0;
	m=m-1; it=0;
	}
	else if (l==m-2)
	{ b=-(a[ii]+a[ll]);
	c=a[ii]*a[ll]-a[jj]*a[kk];
	w=b*b-4.0*c;
	y=sqrt(fabs(w));
	if (w>0.0)
	{ xy=1.0;
	if (b<0.0) xy=-1.0;
	u[m-1]=(-b-xy*y)/2.0;
	u[m-2]=c/u[m-1];
	v[m-1]=0.0; v[m-2]=0.0;
	}
	else
	{ u[m-1]=-b/2.0; u[m-2]=u[m-1];
	v[m-1]=y/2.0; v[m-2]=-v[m-1];
	}
	m=m-2; it=0;
	}
	else
	{ if (it>=jt)
	{ 
		if(ck==0)
			ck=3;
		return(0);
	}
	it=it+1;
	for (j=l+2; j<=m-1; j++)
		a[j*n+j-2]=0.0;
	for (j=l+3; j<=m-1; j++)
		a[j*n+j-3]=0.0;
	for (k=l; k<=m-2; k++)
	{ if (k!=l)
	{ p=a[k*n+k-1]; q=a[(k+1)*n+k-1];
	r=0.0;
	if (k!=m-2) r=a[(k+2)*n+k-1];
	}
	else
	{ x=a[ii]+a[ll];
	y=a[ll]*a[ii]-a[kk]*a[jj];
	ii=l*n+l; jj=l*n+l+1;
	kk=(l+1)*n+l; ll=(l+1)*n+l+1;
	p=a[ii]*(a[ii]-x)+a[jj]*a[kk]+y;
	q=a[kk]*(a[ii]+a[ll]-x);
	r=a[kk]*a[(l+2)*n+l+1];
	}
	if ((fabs(p)+fabs(q)+fabs(r))!=0.0)
	{ xy=1.0;
	if (p<0.0) xy=-1.0;
	s=xy*sqrt(p*p+q*q+r*r);
	if (k!=l) a[k*n+k-1]=-s;
	e=-q/s; f=-r/s; x=-p/s;
	y=-x-f*r/(p+s);
	g=e*r/(p+s);
	z=-x-e*q/(p+s);
	for (j=k; j<=m-1; j++)
	{ ii=k*n+j; jj=(k+1)*n+j;
	p=x*a[ii]+e*a[jj];
	q=e*a[ii]+y*a[jj];
	r=f*a[ii]+g*a[jj];
	if (k!=m-2)
	{ kk=(k+2)*n+j;
	p=p+f*a[kk];
	q=q+g*a[kk];
	r=r+z*a[kk]; a[kk]=r;
	}
	a[jj]=q; a[ii]=p;
	}
	j=k+3;
	if (j>=m-1) j=m-1;
	for (i=l; i<=j; i++)
	{ ii=i*n+k; jj=i*n+k+1;
	p=x*a[ii]+e*a[jj];
	q=e*a[ii]+y*a[jj];
	r=f*a[ii]+g*a[jj];
	if (k!=m-2)
	{ kk=i*n+k+2;
	p=p+f*a[kk];
	q=q+g*a[kk];
	r=r+z*a[kk]; a[kk]=r;
	}
	a[jj]=q; a[ii]=p;
	}
	}
	}
	}
	}
	return(1);
}

int dqrrt(double a[],int n,double xr[],double xi[],double eps,int jt)
{ 
	int i,j;
	double *q;
	q=(double*)malloc(n*n*sizeof(double));
	for (j=0; j<=n-1; j++)
		q[j]=-a[n-j-1]/a[n];
	for (j=n; j<=n*n-1; j++)
		q[j]=0.0;
	for (i=0; i<=n-2; i++)
		q[(i+1)*n+i]=1.0;
	i=chhqr(q,n,xr,xi,eps,jt);
	free(q); return(i);
}



int check_equation(string& target, int& n)
{
	eraser_space(target);

	if((target[target.length()-1]!='0')||(target[target.length()-2]!='='))
	{
		if(ck==0)
			ck=4;
		//cout << "����ȱ�ٵȺŻ��ұ߲�Ϊ��" << endl;
		return 0;
	}
	else
	{
		target.replace(target.length()-2,2,"");
		if((target[target.length()-1]=='x')||(target[target.length()-1]=='X'))
		{
			target.replace(target.length()-1,1,"x^1");
		}
		string temp = target;
		string op[10] = {"x+","x-","X+","X-","+","-","*x^","*X^","x^","X^"};

		int x;
		for (int i=0 ;i<10 ;i++)
		{
			x = temp.find(op[i]);
			while(x < string::npos)
			{
				temp.replace(x,op[i].length(),"");
				x = temp.find(op[i]);
			}
		}
		cout << temp << endl;

		for (int i=0 ;i<temp.length() ;i++)
		{
			if ((temp[i]<46)||(temp[i]>57)||(temp[i]==47))
			{//cout << i << endl;
				//	cout << "���ַǷ��ַ�" << endl;
				if(ck==0)
					ck=5;
				return 0;
			}
		}


		for (int i=6 ;i<10 ;i++)
		{
			x =	target.find(op[i]);
			while(x < string::npos)
			{
				target.replace(x,op[i].length(),"x");
				x = target.find(op[i]);
			}
		}
		cout << target << endl;

		if (target[0] == 'x')
		{
			target = "1" + target;
		}
		x = target.find("+x");
		while(x < string::npos)
		{
			target.replace(x,2,"+1x");
			x = target.find("+x");
		}
		x = target.find("-x");
		while(x < string::npos)
		{
			target.replace(x,2,"-1x");
			x = target.find("-x");
		}
		x = target.find("x+");
		while(x < string::npos)
		{
			target.replace(x,2,"x1+");
			x = target.find("x+");
		}
		x = target.find("x-");
		while(x < string::npos)
		{
			target.replace(x,2,"x1-");
			x = target.find("x-");
		}

		//	cout << target << endl;

		temp = target;                   
		x = temp.find("-");
		while(x < string::npos)
		{
			temp.replace(x,1,"+");
			x = temp.find("-");
		}
		x = 0;
		//	cout << temp << endl;
		//cout <<x << endl;
		int y;
		int z;
		while(x!=temp.length())
		{
			cout << "x" << x << endl;
			y = temp.find("+",x+1);
			if(y==string::npos)
			{
				y = temp.length();
			}
			cout << "y" << y << endl;

			z = temp.find("x",x+1);
			if(z==string::npos)
			{
				z = temp.length();
			}
			cout << "z" << z << endl;
			if(z==y)
			{
				target = target + "x0";
			}
			if(z > y)
			{
				temp.replace(y,0,"x0");
				target.replace(y,0,"x0");
				y = y+2;
			}

			x = y;
			cout << target << endl;
		}

		temp = target;

		if(!is_number(temp[temp.length()-1]))
		{
			if(ck==0)
				ck=6;
			//			cout << "ȱָ��" << endl;
			return 0;
		}
		if ((temp[0]=='-')||(temp[0]=='+'))
		{
			temp.replace(0,1,"");
		}
		x = temp.find("x");
		while(x < string::npos)
		{
			temp.replace(x,1,"A");
			x = temp.find("x");
		}

		if(check_invalid_operator(change_func_sign(temp))==0)
		{
			if(ck==0)
				ck=7;
			return 0;
		}

		istringstream inputString(target);
		char cc;
		double d;
		int e;
		while (inputString.good())
		{
			inputString>>d;
			if(inputString.good())
			{
				inputString>>cc;
				if(cc!='x')
				{
					if(ck==0)
						ck=8;
					//				cout << "�Ƿ�" << endl;
					return 0;
				}
				else
				{
					inputString >> cc;
					//	cout << "ccccc" << cc << endl;
					if(is_number(cc))
					{
						inputString.putback(cc);
						inputString >> e;
						//		cout << "EEEE" << e << endl;
					}
					else
					{
						if(ck==0)
							ck=9;
						//				cout << "�Ƿ�2" << endl;
						return 0;
					}
					if(inputString.good())
					{
						inputString >> cc;
						//		cout << cc << endl;
						if((cc=='+')||(cc=='-'))
						{
							inputString.putback(cc);
						}
						else
						{
							if(ck==0)
								ck=10;
							//							cout << "�Ƿ�3" << endl;
							return 0;
						}
					}
				}
			}
		}
	}	

	int max = 0;
	int x = target.find("x");
	while(x < string::npos)
	{
		max++;
		x = target.find("x",x+1);
	}
	double gar;
	int zhi=0;
	int zhitemp;

	istringstream inputString(target);
	char cc;
	for(int i=0;i<max;i++)
	{
		inputString >> gar;
		inputString >> cc;
		inputString >> zhitemp;
		if(zhitemp>=zhi)
			zhi=zhitemp;
	}

	n=zhi;
	return 1;

}

int is_trt(double a[], int n)
{
	for(int i=1; i<n-1; i++)
	{
		if(a[i]!=0.0)
			return 0;
	}
	return 1;
}
int equation_to_array(string& target,double a[], int n)
{
	int max = 0;
	int x = target.find("x");
	while(x < string::npos)
	{
		max++;
		x = target.find("x",x+1);
	}
	double* b = new double[max];//weeny
	int* c =new int[max];//weeny

	istringstream inputString(target);
	char cc;
	for(int i=0;i<max;i++)
	{
		inputString >> b[i];
		inputString >> cc;
		inputString >> c[i];
	}

	for (int i=0;i<n+1;i++)
	{
		a[i]=0;
	}
	for (int i=0;i<max;i++)
	{
		a[c[i]]=a[c[i]]+b[i];
	}


	delete[] b;
	delete[] c;
	if(a[n]==0)
	{
		if(ck==0)
			ck=11;
		return 0;
	}
	return 1;
}


int equation(string& res, double a[], int n)
{
	if(!is_trt(a, n))
	{
		double* xr=new double[n];
		double* xi=new double[n];
		ostringstream oss;
		dqrrt(a, n, xr, xi, 0.000000001, 88);
		for (int i=0;i<n;i++)
		{
			oss<<"X("<<i<<")="<<setprecision(14)<<xr[i]<<"\r\n         +j"<<setprecision(14)<<xi[i];
			if (i!=n-1)
				oss<<"\r\n";
		}
		res=oss.str();
		delete[] xr;
		delete[] xi;
		return 1;
	}
	else
	{
		complex dest(0.0-a[0]/a[n], 0, 1);
		complex* rest=new complex[n];
		int stat=ontrt(dest, n, rest);
		if(stat)
		{
			ostringstream oss1;
			for(int i=0; i<n; i++)
			{
				oss1<<"X("<<i<<")="<<rest[i].to_string_xy_form();
				if(i!=n-1)
					oss1<<"\r\n";
			}
			res=oss1.str();
			delete[] rest;
			return 1;
		}
		else 
		{
			if(ck==0)
				ck=12;
			return 0;
		}
	}
}

int get_expression_result(string& res, string sour)
{
	int n;
	if(check_equation(sour,n))
	{
		double* a=new double[n+1];
		if (equation_to_array(sour,a, n))
		{
			equation(res, a, n);
			delete[] a;
			return 1;
		}
		else 
		{
			delete[] a;
			if(ck==0)
				ck=13;
			return 0;
		}
	}
	else
	{
		if(ck==0)
			ck=14;
		return 0;
	}
}


