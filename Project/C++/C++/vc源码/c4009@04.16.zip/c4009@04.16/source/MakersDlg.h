#pragma once


// CMakersDlg �Ի���

class CMakersDlg : public CDialog
{
	DECLARE_DYNAMIC(CMakersDlg)

public:
	CMakersDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMakersDlg();
	void ShowPhoto(CPaintDC* pdc, int a, int b);


// �Ի�������
	enum { IDD = IDD_MAKERS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
};
