// ExampleDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"
#include <string>
#include "afxwin.h"
#include "MakersDlg.h"
using namespace std;
enum Operator { OpNone, OpAdd, OpSubtract, OpMultiply, OpDivide };
enum mOperator{ OpMNone, OpMAdd, OpMSub, OpMMul, OpMInv, OpMChara, OpMt, OpMdet};
enum CalcError { ErrNone, ErrDivideByZero };


#define PI 3.1415926

// CExampleDlg �Ի���
class CExampleDlg : public CDialog
{
	// ����
public:
	CExampleDlg(CWnd* pParent = NULL);	// ��׼���캯��
	//weeny-----------------------------------------------------------
	string matr;
	void toLower(string& s);
	CBitmap m_bmpBitmap;
	void Ball();
	/////////////////////////////////////////////////////
	BOOL m_bOneEquation;
	BOOL m_bOneMatrix;
	string str1, str2;	
	BOOL m_bRorC;
	double m_operand;
	double m_accum;
	BOOL m_bCoff;
	double m_coff;


	Operator m_operator;
	CalcError m_errorState;
	BOOL m_bOperandAvail;

	void Calculate();
	void UpdateDisplay();
	void Set_EQerror(int w);//need
	//weeny-------------------------------------------------------------



	// �Ի�������
	enum { IDD = IDD_EXAMPLE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


	// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	CTabCtrl m_Tab;
	afx_msg void OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void toEXIT();
	afx_msg void toReal();
	afx_msg void toComplex();
	afx_msg void toCharacter();
	afx_msg void toMadd();
	afx_msg void toMsub();
	afx_msg void toMmul();
	afx_msg void toMdet();
	afx_msg void toMt();
	afx_msg void toMinv();
	afx_msg void toYiYuan();
	afx_msg void toFChZu();
	afx_msg void top2Result();
	afx_msg void toM1();

	CString m_p2strInput;//weeny
	void Set_Error(int w);
	void Set_Merror(int w);
	string to_matrix_form(string s, int li, int co);
	BOOL PreTranslateMessage(MSG* pMsg);
	CString m_p2strResult;
	CString m_strHelp;
	CString m_p3strM1;
	CString m_p3strM2;
	CString m_p3strResult;
	mOperator Moptr;
	afx_msg void toMResult();
	string cs2s(CString& weeCS);
	CString s2cs(string& weeS);
	CString m_p4strMcoff;
	CString m_p4strMb;
	CString m_p4strE;
	afx_msg void toEQResult();
	CString m_p4strResult;
	afx_msg void ShowM1();
	afx_msg void ShowM2();

	//page1(by wanghao)
protected:
public:
	enum p1_Operator{p1_OpNone,p1_OpAdd,p1_OpSubtract,p1_OpMultiply,p1_OpDivide,p1_OpPower,p1_OpSqre};
	enum p1_CalcError {p1_ErrNone, p1_ErrDivideByZero};
	enum p1_ComplexorReal {p1_Real,p1_Complex};
	//enum p1_Func { p1_FuncPow,p1_FuncSqrt, p1_FuncSqre,p1_FuncNone};

	HICON m_p1_hIcon;
	HACCEL m_p1_hAccel;

	long double m_p1_operand;
	long double m_p1_accum;
	CString m_p1_result;
	BOOL m_p1_bCoff;
	double m_p1_coff;
	p1_Operator m_p1_operator;
	p1_CalcError m_p1_errorState;
	//p1_Func m_p1_func;
	BOOL m_p1_bOperandAvail;
	BOOL m_p1_C;//��ʱ���
	int m_p1_j;
	int m_p1_angle;
	int m_p1_sign;
	int m_p1_Point;
	int m_p1_Equal;
	int m_p1_k;
	

	BOOL m_p1_pow_poi;
	BOOL m_p1_Cxyavalue;
	BOOL m_p1_equal;


	CString m_p1_complex_operand;
	CString m_p1_complex_accum;
	p1_ComplexorReal p1_CorR;

	int m_p1_Sqre;
	int m_p1_sqr_poi;
	string* m_p1_sarray_accum;
	CString* m_p1_csarray_accum;

	void p1_Calculate();
	void p1_UpdateDisplay();
	int p1_translate(UINT nID);
	char p1_complex_translate(UINT nID);
	

	//virtual BOOL PreTranslateMessage(MSG* pMsg);

	//afx_msg void OnSysCommand(UINT nID,LPARAM lParam);
	afx_msg BOOL p1_Keyboard(LPCTSTR szButton);
	//afx_msg void p1_OnPaint();
	afx_msg HCURSOR p1_OnQueryDragIcon();
	afx_msg void p1_OnAdd();
	afx_msg void p1_OnMinus();
	afx_msg void p1_OnDivid();
	afx_msg void p1_OnMultiply();
	afx_msg void p1_OnEqual();
	afx_msg void p1_OnClear();
	afx_msg void p1_OnAllClear();

	//afx_msg void p1_OnPower();
	//afx_msg void p1_OnSqre();
	afx_msg void p1_OnPoint();
	afx_msg void p1_OnOperandInput(UINT nID);
	afx_msg void p1_OnSign();
	//afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void p1_OnJ();
	afx_msg void p1_OnAngle();
	afx_msg void p1_OnChange();
	afx_msg void p1_OnPower();
	afx_msg void p1_OnSqre();

	afx_msg void p1_OnOKSqre();	
	//��������ʱʹ��
	CComboBox m_p1_ComboBox;
	CString m_p1_Combox1;

	CMakersDlg m_dlgM;

};
