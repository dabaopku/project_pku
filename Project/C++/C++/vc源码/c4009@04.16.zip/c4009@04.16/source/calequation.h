#ifndef CALEQUATION_H
#define CALEQUATION_H

int get_expression_result(string& res, string sour);
int cal_equations(string coff, string b, string& res);
#endif
