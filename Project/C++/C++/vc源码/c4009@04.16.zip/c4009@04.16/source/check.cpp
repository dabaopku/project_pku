#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"

#include<iostream>
#include<string>
#include<sstream>
#include "check.h"
using namespace std;

const int op_size=33;
string op[op_size] = 
{"&&",	"||",	">=",	"<=",	"==",
"!=",	"~",	">",	"<",	"+",
"-",	"*",	"/",	"%",	"^",
"and", "xor",	"or",	"logxy","ex",
"asin","acos",	"atan",	"actan","ctan",	//下标19到29为单元运算符
"sin",	"cos",	"tan",	"ln",	"log",	
"!",	"(",	")"	};
string new_op[op_size] = 
{"&",	"|",	"d",	"x",	"q",
"n",	"~",	">",	"<",	"+",
"-",	"*",	"/",	"%",	"^",
"a",	"X",	"o",	"g",	"p",
"s",	"c",	"t",	"r",	"A",	
"S",	"C",	"T",	"N",	"l",
"f",	"(",	")"	};
int wk=0;//设置WrongKey被ExampleDlg.cpp调用
//wk=1: 小数点两边出现不是数字的情况
//wk=2: 阶乘前面不能是一个小数
//wk=3: 取余运算不能用于小数
//wk=4: 表达式中左右括号不配对
//wk=5; 表达式中左括号前缺少运算符
//wk=6; 表达式中右括号后缺少运算符
//wk=7; 表达式中左右括号不配对
//wk=8; 表达式中左右括号数目不相等
//wk=9; 出现不在字母表中的字符
//wk=10:函数后面缺少数字
//wk=11:出现类似123.456.789的情况
//wk=12:出现非法使用的运算符
//wk=13:函数名前面发现错误
//wk=14:阶乘后面发现错误
//wk=15:表达式为空
int is_number(char ch)//判断一个char是不是num，是的话返回1，不是则返回0
{
	return (ch>='0' && ch<='9');
}

int check_dot_use(string& s)
{
	int x=s.find(".");
	while(x<string::npos)
	{
		if (x==0 || x==s.length()-1 || (s.at(x-1)>'9') ||(s.at(x-1)<'0') || (s.at(x+1)>'9') || (s.at(x+1)<'0'))
			//如果小数点在第一位或最后一位或是两头不是数字，报错
		{
			wk=1;
			return 0;
		}
		int num=x+1;
		int tnum=x-1;
		while ((tnum>=0))
		{
			if(s.at(tnum)<'0' || s.at(tnum)>'9')
			{
				if(s.at(tnum)=='%')
				{
					wk=3;
					return 0;
				}
			}
			tnum--;
		}
		while ((num<s.length()))
		{
			if (s.at(num)<'0' || s.at(num)>'9')
			{//阶乘不能是小数
				if (s.at(num)=='!')
				{
					wk=2;
					return 0;
				}
				if (s.at(num)=='%')
				{
					wk=3;
					return 0;
				}
				else break;
			}
			num++;
		}
		x=s.find(".", x+1);
	}
	return 1;
}
void eraser_space(string& s)//删除一个串中的所有空格
{
	int x=s.find(" ");
	while(x<string::npos)
	{
		s.replace(x,1,"");
		x=s.find(" ", x);
	}
}

int check_brackets(string& s)//检测括号配对情况, 正确返回1, 错误返回0
{
	int count=0;	
	int t=0;
	while(t<string::npos)
	{
		int x=s.find("(",t);
		int y=s.find(")",t);
		if(x==y) break;
		if(x>=0 && y<0)
		{
			wk=4;
			return 0;
		}
		if(x>=0 && y>0 && x<y)
		{
			t=x;
			if (t>0&&(s.at(t-1)==')'||(s.at(t-1)>='0'&&s.at(t-1)<='9'||s.at(t-1)=='!') ))
				//如果左括号前面是右括号，或是字母或是数字则，报错
			{
				wk=5;
				return 0;
			}
			count++;
			t++;
		}
		else
		{
			t=y;
			if (t+1<s.length()&&(s.at(t+1)=='('||(s.at(t+1)>='0'&&s.at(t+1)<='9') || (s.at(t+1)>='a'&&s.at(t+1)<='z')))
				//如果右括号后面是作括号，或是数字字母，报错
			{
				wk=6;
				return 0;
			}
			count--;
			t++;
			if(count<0)
			{//如果某处以前的左括号数目小于右括号数，报错
				wk=7;
				return 0;
			}
		}
	}
	if(count==0)
		return 1;
	else
	{//如果左括号和右括号数目不同，报错
		wk=8;
		return 0;
	}
}


int check_invalid_char(string target) //检查非法字符 正确返回1, 错误返回0
{

	int x;
	for (int i=0 ;i<op_size ;i++)
	{
		x = target.find(op[i]);
		while(x < string::npos)
		{
			target.replace(x,op[i].length(),"");
			x = target.find(op[i]);
		}
	}

	for (int i=0 ;i<target.length() ;i++)
	{
		if ((target[i]<46)||(target[i]>57)||(target[i]==47))
		{
			wk=9;
			return 0;
		}
	}
	//如果除去所有的运算符号还有特殊符号，报错
	return 1;
}

int first_matched_bracket(string & s, int i)//寻找第一个配对的右括号，i是string中作括号的位置，返回右括号的位置
{
	int count=0;
	int t=i;
	while(1)
	{
		int x=s.find("(",t);
		int y=s.find(")",t);
		if(x==y) break;
		if(x>=0 && x<y)
		{
			t=x;
			t++;
			count++;
		}
		else
		{
			t=y;
			count--;
			if (count==0)
			{
				return t;
			}
			t++;

		}
	}
	return s.length()-1;
}

int first_double(string & s, int i)//这个位置开始截取第一个double型量，i是开始数字的位置，返回最后一个数字在string中的位置
{
	while(i<s.length() && ((s.at(i)>='0' && s.at(i)<='9') || s.at(i)=='.'))
	{
		i++;
	}
	return --i;

}

int change_func_form(string& s, int i,string name)//将单元运算符改成双元运算负，返回单元长度－1
{
	int start=i+name.length();
	int beginning;
	int end;
	string temp;

	int temp1=s.find("(",start);
	if (temp1==string::npos)
		temp1=s.length();
	int temp2=start;
	while (temp2<s.length()&&(s.at(temp2)>'9'||s.at(temp2)<'0'))
	{
		temp2++;
		if (temp2>=s.length())
		{
			break;
		}
	}
	if (temp1>0&&(temp1<=temp2))
	{
		beginning=temp1;
		if (temp2>=s.length())
		{
			wk=10;//不知道做什么用
			return 0;
		}
	}
	else beginning=temp2;
	if (s.at(beginning)=='(')
	{
		end=first_matched_bracket(s, beginning);
	}
	else
	{
		end=first_double(s, beginning);
	}
	temp="("+s.substr(i+name.length(), end-start+1)+name+"1)";
	s.replace(i, end-i+1, temp);
	return temp.length()-1;
}



int make_op(string& target)//将target变成所要求的表达式（最后一步）
{
	int x = 0;
	x = target.find("-");
	while(x<string::npos)
	{
		if(((target[x-1]<48)||(target[x-1]>57))&&(target[x-1]!=')'))
		{
			if (target[x+1]=='(')
			{
				target.replace(first_matched_bracket(target, x+1)+1,0,")");
			}
			else 
				if ((target[x+1]>='0')||(target[x+1]<='9'))
				{
					target.replace(first_double(target, x+1)+1,0,")");
				}
				target.replace(x,0,"(0");
		}
		x = target.find("-",x+3);
	}

	for ( int i=0;i<op_size ;i++ )
	{
		x = target.find(op[i]);
		while(x<string::npos)
		{
			target.replace(x,op[i].length(),new_op[i]);
			x=target.find(op[i], x+1);
		}
	}

	x=target.rfind("f");//从后向前找f，并加上括号
	while (x>0)
	{
		int tem=x-1;
		while (tem>0 && (target.at(tem)=='f' || (target.at(tem)>='0'&&target.at(tem)<='9')))
		{
			tem--;
		}
		if (target.at(tem)>='0'&& target.at(tem)<='9')
		{
		}
		else tem++;
		cout<<target.at(tem)<<endl;
		cout<<target<<endl;
		target.replace(tem,0,"(");
		cout<<target<<endl;
		target.replace(x+1,1,"f1)");
		cout<<target<<endl;
		x=target.rfind("f",x);
	}

	for (int i=19 ;i<29 ;i++)
	{
		x = target.rfind(new_op[i]);
		//change added below 31/3
		//从后向前替换，以免错过coscos的情况
		while(x>=0)
		{			
			change_func_form(target,x,new_op[i]);
			if (x<=0)
			{
				break;
			}
			x--;
			x=target.rfind(new_op[i],x);
		}
	}
	return 1;
}


string remove_bracket(string target) //去括号
{
	int x = target.find("(");
	while( x < string::npos )
	{
		target.replace(x,1,"");
		x = target.find("(",x);
	}

	x = target.find(")");
	while( x < string::npos )
	{
		target.replace(x,1,"");
		x = target.find(")",x);
	}
	return target;
}
string change_func_sign(string s) //把运算符和函数名都变成"A"
{
	for(int i=0; i<op_size; i++)
	{
		int x=s.find(op[i]);
		while(x<string::npos)
		{
			s.replace(x,new_op[i].length(),"A");
			x=s.find(op[i],x+1);
		}
	}
	return s;
}


int check_invalid_operator(string& s)
//判断一个没有空格的只有数字小数点和A的串是不是合法
//包括1.2.3的情况和开头结尾不是double的情况
//然后中间一定是double和A交替出现
{
	istringstream inputString(s);
	char cc;
	double d;
	while (inputString.good())
	{
		inputString>>cc;
		if(is_number(cc))
		{
			inputString.putback(cc);
			inputString>>d;
			if(inputString.good())
			{
				inputString>>cc;
				if(cc=='.')
				{
					wk=11;
					return 0;
				}

			}

		}
		else 
		{
			wk=12;
			if(s=="")
				wk=15;
			return 0;
		}
	}
	return 1;
}


int check_invalid_links(string & s)//检查一员变二元会掩盖掉的问题
//如3!1或3cos2之类
//任何一个函数名的前面不能是.或是数字或是！
{
	for (int i=19;i<30 ;i++ )
	{
		int x=s.find(op[i]);
		if (x==0)
			x=s.find(op[i],x+op[i].length());
		while(x<string::npos )
		{
			char t=s.at(x-1);
			if (t=='.'||(t>='0'&&t<='9')||t=='!')
			{
				wk=13;
				return 0;
			}
			x=s.find(op[i],x+op[i].length());
		}
	}

	int x=s.find("!");
	while(x<string::npos && x+1<s.length())
	{
		char t=s.at(x+1);
		if (t=='.'||(t>='0'&&t<='9')||(t>='a'&&t<='z'))
		{
			wk=14;
			return 0;
		}
		x=s.find("!",x+1);
	}



	return 1;
}

int check_normal_expression(string& s)
//输入string，判断是不是合法并且进行格式转换，得到标准的格式
//返回如果是1，则表达式合法
{
	eraser_space(s);
	if( check_brackets(s) && check_dot_use(s))
	{
		if( check_invalid_char(s) )
		{
			string temp3 = remove_bracket(s);
			int w1=make_op(s);
			int w2=check_invalid_links(temp3);
			if (w1&&w2)
			{
				string temp1 = remove_bracket(s);
				string temp2 = change_func_sign(temp1);
				if( check_invalid_operator(temp2))
				{
					return 1;
				}
				else return 0;
			}
			else return 0;
		}
		else return 0;
	}
	else return 0;
}

