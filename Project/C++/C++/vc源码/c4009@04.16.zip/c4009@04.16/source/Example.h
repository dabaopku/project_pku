// Example.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// ������


// CExampleApp:
// �йش����ʵ�֣������ Example.cpp
//

class CExampleApp : public CWinApp
{
public:
	CExampleApp();

// ��д
	public:
	virtual BOOL InitInstance();
	/*BOOL ProcessMessageFilter(int code,LPMSG lpMsg)
	{
		if(m_p1_hAccel)
		{
			if(::TranslateAccelerator(m_pMainWnd->m_hWnd,m_p1_hAccel, lpMsg))
				return(TRUE);
		}
		return CWinApp::ProcessMessageFilter(code,lpMsg);
	}*/

// ʵ��

	DECLARE_MESSAGE_MAP()
};

extern CExampleApp theApp;
