#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"
#include "MakersDlg.h"

#include "check.h"
#include "ProcExpr.h"
#include "calmatrix.h"
#include "calcomplex.h"
#include "calequation.h"
#include <iomanip>
#include ".\exampledlg.h"
#include <string>

#include<sstream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CExampleDlg �Ի���
extern int wk;
extern int mk;
extern int ck;

CExampleDlg::CExampleDlg(CWnd* pParent /*=NULL*/)
: CDialog(CExampleDlg::IDD, pParent)
, m_p2strInput(_T(""))
, m_p2strResult(_T(""))
, m_strHelp(_T(""))
, m_p3strM1(_T(""))
, m_p3strM2(_T(""))
, m_p3strResult(_T(""))
, m_p4strMcoff(_T(""))
, m_p4strMb(_T(""))
, m_p4strE(_T(""))
, m_p4strResult(_T(""))
, Moptr(OpMNone)
, m_bOneEquation(FALSE)
, m_bOneMatrix(FALSE)

, m_p1_result(_T(""))
,m_p1_operand(0)
,m_p1_accum(0)
,m_p1_coff(0.1)
,m_p1_bCoff(0)
,m_p1_errorState(p1_ErrNone)
,m_p1_bOperandAvail(FALSE)
,m_p1_operator(p1_OpNone)
,m_p1_C(0)
,p1_CorR(p1_Real)
,m_p1_complex_operand(_T(""))
,m_p1_complex_accum(_T("0"))
, m_p1_j(1)
,m_p1_sign(1)
,m_p1_angle(1)
,m_p1_Point(1)
,m_p1_Equal(1)
,m_p1_Cxyavalue(TRUE)
,m_p1_equal(TRUE)
, m_p1_pow_poi(0)
,m_p1_Sqre(0)
,m_p1_sqr_poi(0)
, m_p1_Combox1(_T(""))
{
	m_p1_hAccel = LoadAccelerators(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDD_EXAMPLE_DIALOG));
}

void CExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB1, m_Tab);
	DDX_Text(pDX, IDC_INPUT, m_p2strInput);
	DDX_Text(pDX, IDC_RESULT, m_p2strResult);
	DDX_Text(pDX, IDC_HEL, m_strHelp);
	DDX_Text(pDX, IDC_M1, m_p3strM1);
	DDX_Text(pDX, IDC_M2, m_p3strM2);
	DDX_Text(pDX, IDC_MRESULT, m_p3strResult);
	DDX_Text(pDX, IDC_MCOFF, m_p4strMcoff);
	DDX_Text(pDX, IDC_MB, m_p4strMb);
	DDX_Text(pDX, IDC_EXPRESSION, m_p4strE);
	DDX_Text(pDX, IDC_EQRESULT, m_p4strResult);
	DDX_Text(pDX, IDC_EDIT1, m_p1_result);
	DDX_Control(pDX, IDC_COMPLEX_COMBO1, m_p1_ComboBox);
	DDX_CBString(pDX, IDC_COMPLEX_COMBO1, m_p1_Combox1);
}

BEGIN_MESSAGE_MAP(CExampleDlg, CDialog)

	//ON_WM_SYSCOMMAND()
	//ON_WM_PAINT()
	//ON_WM_QUERYDRAGICON()	
	//ON_COMMAND_RANGE(IDC_NUMBER1, IDC_NUMBER0, OnNumberKey)
	ON_COMMAND_RANGE(IDC_1, IDC_0, p1_OnOperandInput)
	//	ON_BN_CLICKED(IDC_0, p1_OnAdd)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnTcnSelchangeTab1)
	ON_BN_CLICKED(IDC_EXIT, toEXIT)
	ON_BN_CLICKED(IDC_REAL, toReal)
	ON_BN_CLICKED(IDC_COMPLEX, toComplex)
	ON_BN_CLICKED(IDC_M_cha, toCharacter)
	ON_BN_CLICKED(IDC_M_add, toMadd)
	ON_BN_CLICKED(IDC_M_sub, toMsub)
	ON_BN_CLICKED(IDC_M_mul, toMmul)
	ON_BN_CLICKED(IDC_M_div, toMinv)
	ON_BN_CLICKED(IDC_MDET, toMdet)
	ON_BN_CLICKED(IDC_MT, toMt)
	ON_BN_CLICKED(IDC_FCHZU, toFChZu)
	ON_BN_CLICKED(IDC_YIYUAN, toYiYuan)
	ON_BN_CLICKED(IDC_CALC, top2Result)
	ON_BN_CLICKED(IDC_MCALC, toMResult)
	ON_BN_CLICKED(IDC_EQCALC, toEQResult)
	ON_BN_CLICKED(IDC_toM1, toM1)
	ON_BN_CLICKED(IDC_M1SHOW, ShowM1)
	ON_BN_CLICKED(IDC_M2SHOW, ShowM2)


	ON_BN_CLICKED(IDC_ADD, p1_OnAdd)
	ON_BN_CLICKED(IDC_SUB, p1_OnMinus)
	ON_BN_CLICKED(IDC_DIV, p1_OnDivid)
	ON_BN_CLICKED(IDC_MUL, p1_OnMultiply)
	ON_BN_CLICKED(IDC_EQUAL, p1_OnEqual)
	ON_BN_CLICKED(IDC_sign, p1_OnSign)
	ON_BN_CLICKED(IDC_POINT, p1_OnPoint)
	ON_BN_CLICKED(IDC_C, p1_OnClear)
	ON_BN_CLICKED(IDC_AC, p1_OnAllClear)
	ON_BN_CLICKED(IDC_cXY, p1_OnJ)
	ON_BN_CLICKED(IDC_cANGLE, p1_OnAngle)
	ON_BN_CLICKED(IDC_cFORM, p1_OnChange)
	ON_BN_CLICKED(IDC_POWER, p1_OnPower)
	ON_BN_CLICKED(IDC_SQRE, p1_OnSqre)
	ON_BN_CLICKED(IDC_CLOSECOMBO, p1_OnOKSqre)


	//ON_COMMAND(IDD_EXAMPLE_DIALOG,)
	//ON_BN_CLICKED(IDC_SQRE, p1_OnSqre)
	//ON_BN_CLICKED(IDC_CLEAR, OnClear)
	/*ON_BN_CLICKED(IDC_LOG, OnLog)
	ON_BN_CLICKED(IDC_LN, OnLn)
	ON_BN_CLICKED(IDC_FACTORIAL, OnFactorial)
	ON_BN_CLICKED(IDC_EXP, OnExp)
	ON_BN_CLICKED(IDC_SENTIFIC, OnSentific)
	ON_BN_CLICKED(IDC_SIN, OnSin)
	ON_BN_CLICKED(IDC_SQUAR, OnSquar)
	ON_BN_CLICKED(IDC_TAN, OnTan)
	ON_BN_CLICKED(IDC_STANDARD, OnStandard)
	ON_BN_CLICKED(IDC_DEGREE, OnDegree)
	ON_BN_CLICKED(IDC_RAD, OnRad)
	ON_BN_CLICKED(IDC_COS, OnCos)
	ON_BN_CLICKED(IDC_RorC, OnRorC)
	ON_BN_CLICKED(IDC_J, OnJ)*/

	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

// CExampleDlg ��Ϣ��������
BOOL CExampleDlg::OnInitDialog()
{
	m_p2strInput="";//weeny
	CDialog::OnInitDialog();
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��
	// TODO���ڴ����Ӷ���ĳ�ʼ������
	m_dlgM.Create(IDD_MAKERS, this);

	m_p1_result="0.";
	m_p1_hAccel=LoadAccelerators(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDD_EXAMPLE_DIALOG));
	{
		TCITEM tcItem1;
		tcItem1.mask = TCIF_TEXT;
		tcItem1.pszText = _T("��������");
		m_Tab.InsertItem(0, &tcItem1);
		TCITEM tcItem2;
		tcItem2.mask = TCIF_TEXT;
		tcItem2.pszText = _T("����ʽ");
		m_Tab.InsertItem(1, &tcItem2);
		TCITEM tcItem3;
		tcItem3.mask = TCIF_TEXT;
		tcItem3.pszText = _T("����");
		m_Tab.InsertItem(2, &tcItem3);
		TCITEM tcItem4;
		tcItem4.mask = TCIF_TEXT;
		tcItem4.pszText = _T("����");
		m_Tab.InsertItem(3, &tcItem4);
		TCITEM tcItem5;
		tcItem5.mask = TCIF_TEXT;
		tcItem5.pszText = _T("����");
		m_Tab.InsertItem(4, &tcItem5);
	}
	m_Tab.SetCurSel(0);
	{
		GetDlgItem(IDC_1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_3)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_4)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_5)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_6)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_7)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_8)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_9)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_0)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_AC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_C)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_sign)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MSUB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MMUL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MINV)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_HIDE);
			
//wanghao
		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);

	}
	toReal();
	GetDlgItem(IDC_EXPRESSION)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATIC10)->EnableWindow(FALSE);
	m_strHelp="        Ŀǰ�����Ѿ����������, ���й�������\
			  \r\n\r\n                              PAGE 2:\
			  \r\n        �ڱ���ʽ�п���֧�ֵĲ�������sin, cos, tan, ln, ex(e��x�η�),  asin, acos, atan, !(�׳�), +, -, *, /, %(ȡ��), ��������������, (����ʽ�в���ʡ��*��), ֧��!=, >=, >, <, <=, �ж�����, ֧��&&, ||, or, xor,�߼�����\
			  \r\n\r\n                              PAGE 3:\
			  \r\n        �ھ��������,����Ϸ�����Ϊ\r\n[a,b;c,d;] ����a,b,c,d����Ϊ����ʽ, ͷβ�÷�����,Ԫ�ؼ��ö���,ÿһ�н�����Ҫ��һ���ֺ�\
			  \r\n\r\n                              PAGE 4:\
			  \r\n        ���������Ҫ������ϵ�������b����, ���ж����վ�������еľ����ʽ����, �ر�Ҫ��b���������һ���о���, ���о�����Ԫ�ض�����ʹ�ñ���ʽ. ��ȡ���̱���ʽʱ��xΪ����, ָ��ֻ֧�ִ���0������. ������=0Ϊ��β";
	UpdateData(FALSE);
	return TRUE;  // ���������˿ؼ��Ľ��㣬���򷵻� TRUE	
}


void CExampleDlg::Ball()
{
	m_dlgM.ShowWindow(SW_SHOW);
	HBITMAP hBitmap; 
	HINSTANCE hInstResource=AfxFindResourceHandle(MAKEINTRESOURCE(IDB_BITMAP2),RT_BITMAP); 
	hBitmap=(HBITMAP)::LoadBitmap(hInstResource,MAKEINTRESOURCE(IDB_BITMAP2));
	if (hBitmap)
	{
		if(m_bmpBitmap.DeleteObject())
			m_bmpBitmap.Detach();
		m_bmpBitmap.Attach(hBitmap);

	}
	
	m_dlgM.Invalidate();

}

void CExampleDlg::toLower(string& s)
{
//	string tt[]={"a", "b", "c","d", "e", "f","g", "h", "i","j", "k", "l","m", "n", "o","p", "q", "r","s", "t", "u","v", "w", "x","y", "z"};
	for(int i=0; i<s.length(); i++)
	{
		if(s.at(i)>='A'&&s.at(i)<='Z')
		{
			CString cs((char(s.at(i)+32)));
			string tt=cs2s(cs);
//			string tt("a");
//			char cha=s.at(i);
  //          int tem=cha;
//			cha=(tem+20);
			s.replace(i,1,tt);//char(int(s.at(i))+20));
		}
	}
}



void CExampleDlg::OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int iPage=m_Tab.GetCurSel();
	switch(iPage)
	{
	case 0:
		GetDlgItem(IDC_1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_3)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_4)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_5)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_6)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_7)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_8)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_9)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_0)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_AC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_C)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_COMPLEX)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_sign)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MADD)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MSUB)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MMUL)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MINV)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);



		break;
	case 1:

		GetDlgItem(IDC_1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_0)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_AC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMPLEX)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_sign)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_INPUT)->SetFocus();
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MADD)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MSUB)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MMUL)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MINV)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_HIDE);


		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);


		break;


	case 2:
		GetDlgItem(IDC_1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_0)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_AC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMPLEX)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_sign)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);



		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M1)->SetFocus();
		GetDlgItem(IDC_M2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_SHOW);
		//		GetDlgItem(IDC_MADD)->ShowWindow(SW_SHOW);
		//		GetDlgItem(IDC_MSUB)->ShowWindow(SW_SHOW);
		//		GetDlgItem(IDC_MMUL)->ShowWindow(SW_SHOW);
		//		GetDlgItem(IDC_MINV)->ShowWindow(SW_SHOW);
		//		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_SHOW);


		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);


		break;
	case 3:
		GetDlgItem(IDC_1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_0)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_AC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMPLEX)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_sign)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MADD)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MSUB)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MMUL)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MINV)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_HIDE);



		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_MCOFF)->SetFocus();
		GetDlgItem(IDC_MB)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);

		break;
	case 4:
		GetDlgItem(IDC_1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_0)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_AC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_ADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cANGLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cFORM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMPLEX)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_cXY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_DIV)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQUAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MUL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POINT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_POWER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_REAL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_sign)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SQRY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUB)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_INPUT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MRESULT)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MADD)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MSUB)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MMUL)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_MINV)->ShowWindow(SW_HIDE);
		//		GetDlgItem(IDC_CHARACTER)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MDET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M1SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M2SHOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_add)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_sub)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_mul)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_div)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_M_cha)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_toM1)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC10)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC11)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MCOFF)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXPRESSION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQRESULT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EQCALC)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_FCHZU)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_YIYUAN)->ShowWindow(SW_HIDE);

		GetDlgItem(IDC_HEL)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);

	}
	*pResult = 0;
}
void CExampleDlg::toEXIT()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnOK();
}
void CExampleDlg::toReal()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_cANGLE)->EnableWindow(FALSE);
	GetDlgItem(IDC_cFORM)->EnableWindow(FALSE);
	GetDlgItem(IDC_cXY)->EnableWindow(FALSE);
	GetDlgItem(IDC_POWER)->EnableWindow(FALSE);
	GetDlgItem(IDC_SQRY)->EnableWindow(FALSE);
	p1_CorR=p1_Real;

	m_p1_result=_T("");
	m_p1_operand=0;
	m_p1_accum=0;
	m_p1_coff=0.1;
	m_p1_bCoff=0;
	m_p1_errorState=p1_ErrNone;
	m_p1_bOperandAvail=FALSE;
	m_p1_operator=p1_OpNone;
	m_p1_C=0;
	//p1_CorR(p1_Real)
	m_p1_complex_operand=_T("");
	m_p1_complex_accum=_T("0");
	m_p1_j=1;
	m_p1_sign=1;
	m_p1_angle=1;
	m_p1_Point=1;
	m_p1_Equal=1;
	m_p1_Cxyavalue=TRUE;
	m_p1_equal=TRUE;

	m_p1_operand=m_p1_accum=0;
	m_p1_bCoff = 0;
	m_p1_k=1;
	p1_UpdateDisplay();

}
void CExampleDlg::toComplex()
{
	GetDlgItem(IDC_cANGLE)->EnableWindow(TRUE);
	GetDlgItem(IDC_cFORM)->EnableWindow(TRUE);
	GetDlgItem(IDC_cXY)->EnableWindow(TRUE);
	GetDlgItem(IDC_POWER)->EnableWindow(TRUE);
	GetDlgItem(IDC_SQRY)->EnableWindow(TRUE);
	p1_CorR=p1_Complex;

	m_p1_complex_operand=_T("");
	m_p1_complex_accum=_T("0");
	m_p1_result=_T("");
	m_p1_operand=0;
	m_p1_accum=0;
	m_p1_coff=0.1;
	m_p1_bCoff=0;
	m_p1_errorState=p1_ErrNone;
	m_p1_bOperandAvail=FALSE;
	m_p1_operator=p1_OpNone;
	m_p1_C=0;
	//p1_CorR(p1_Real)
	m_p1_complex_operand=_T("");
	m_p1_complex_accum=_T("0");
	m_p1_j=1;
	m_p1_sign=1;
	m_p1_angle=1;
	m_p1_Point=1;
	m_p1_Equal=1;
	m_p1_Cxyavalue=TRUE;
	m_p1_equal=TRUE;
	m_p1_bCoff = 0;
		m_p1_k=1;
	p1_UpdateDisplay();

}
void CExampleDlg::toCharacter()
{
	Moptr=OpMChara;
	if(!m_bOneMatrix)
	{

		GetDlgItem(IDC_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(FALSE);
		m_bOneMatrix=TRUE;
	}
}
void CExampleDlg::toMadd()
{
	Moptr=OpMAdd;
	if(m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(TRUE);
		m_bOneMatrix=FALSE;
	}    
}
void CExampleDlg::toMsub()
{
	Moptr=OpMSub;
	if(m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(TRUE);
		m_bOneMatrix=FALSE;
	}    	
}
void CExampleDlg::toMmul()
{
	Moptr=OpMMul;
	if(m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(TRUE);
		m_bOneMatrix=FALSE;
	}    

}

void CExampleDlg::toMdet()
{
	Moptr=OpMdet;
	if(!m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(FALSE);
		m_bOneMatrix=TRUE;
	}
}
void CExampleDlg::toMt()
{
	Moptr=OpMt;
	if(!m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(FALSE);
		m_bOneMatrix=TRUE;
	}
}
void CExampleDlg::toMinv()
{
	Moptr=OpMInv;
	if(!m_bOneMatrix)
	{
		GetDlgItem(IDC_M2)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC7)->EnableWindow(FALSE);
		m_bOneMatrix=TRUE;
	}
}

void CExampleDlg::toYiYuan()
{
	if(!m_bOneEquation)
	{
		GetDlgItem(IDC_EXPRESSION)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC10)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC9)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC8)->EnableWindow(FALSE);
		GetDlgItem(IDC_MB)->EnableWindow(FALSE);
		GetDlgItem(IDC_MCOFF)->EnableWindow(FALSE);
		m_bOneEquation=TRUE;
	}
}
void CExampleDlg::toFChZu()
{
	if(m_bOneEquation)
	{
		GetDlgItem(IDC_EXPRESSION)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC10)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC9)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATIC8)->EnableWindow(TRUE);
		GetDlgItem(IDC_MB)->EnableWindow(TRUE);
		GetDlgItem(IDC_MCOFF)->EnableWindow(TRUE);
		m_bOneEquation=FALSE;
	}
}

BOOL CExampleDlg::PreTranslateMessage(MSG* pMsg)//need
{
	/*BOOL bHandledMsg=FALSE;
	if (WM_KEYDOWN==pMsg->message && VK_RETURN == pMsg->wParam)
	{
	top2Result();
	pMsg->wParam=(VK_CONTROL & VK_RETURN);
	}*/
	int iPage=m_Tab.GetCurSel();
	switch(iPage)
	{
	case 0:
		if (m_p1_hAccel != NULL && TranslateAccelerator(m_hWnd, m_p1_hAccel, pMsg))
			return TRUE;
		break;
	case 1:
		if (WM_KEYDOWN==pMsg->message && VK_RETURN == pMsg->wParam)
		{
			top2Result();
			pMsg->wParam=(VK_CONTROL & VK_RETURN);
		}
		break;
	case 2:
		if (WM_KEYDOWN==pMsg->message && VK_RETURN == pMsg->wParam)
		{
			toMResult();
			//top2Result();
			pMsg->wParam=(VK_CONTROL & VK_RETURN);
		}
		break;
	case 3:
		if (WM_KEYDOWN==pMsg->message && VK_RETURN == pMsg->wParam)
		{
			toEQResult();
			//top2Result();
			pMsg->wParam=(VK_CONTROL & VK_RETURN);
		}
		break;

	}
	return CDialog::PreTranslateMessage(pMsg);
}
void CExampleDlg::Set_Merror(int w)//need
{
	switch(w)
	{
	case 1:
		m_p3strResult="���һ�����ȱ�ٷֺ�";
		break;
	case 2:
		m_p3strResult="�����197";
		break;
	case 3:
		m_p3strResult="�������в��Ϸ��ı���ʽ";
		break;
	case 4:
		m_p3strResult="����ʽ�����г��ֲ��ɼ�������";
		break;
	case 5:
		m_p3strResult="���������С��һ��";
		break;
	case 6:
		m_p3strResult="����1�����������ھ���2�ĺ���";
		break;
	case 7:
		m_p3strResult="���������,��������";
		break;
	case 8:
		m_p3strResult="�������������������";
		break;
	case 9:
		m_p3strResult="�����ǶԳƾ���";
		break;
	case 10:
		m_p3strResult="����ʲô��û��,�޷�����";
		break;
	case 11:
		m_p3strResult="����ȱ������";
		break;
	}
}
void CExampleDlg::Set_Error(int w)
{
	switch(w)
	{
	case 1:
		m_p2strResult="С�������߳��ֲ������ֵ����";
		break;
	case 2:
		m_p2strResult="�׳�ǰ�治����һ��С��";
		break;
	case 3:
		m_p2strResult="ȡ�����㲻������С��";
		break;
	case 4:
		m_p2strResult="����ʽ���������Ų����";
		break;
	case 5:
		m_p2strResult="����ʽ��������ǰȱ�������";
		break;
	case 6:
		m_p2strResult="����ʽ�������ź�ȱ�������";
		break;
	case 7:
		m_p2strResult="����ʽ���������Ų����";
		break;
	case 8:
		m_p2strResult="����ʽ������������Ŀ�����";
		break;
	case 9:
		m_p2strResult="���ֲ�����ĸ���е��ַ�";
		break;
	case 10:
		m_p2strResult="��������ȱ������";
		break;
	case 11:
		m_p2strResult="��������1.2.3�Ĵ���";
		break;
	case 12:
		m_p2strResult="���ַǷ�ʹ�õ������";
		break;
	case 13:
		m_p2strResult="������ǰ�淢�ִ���";
		break;
	case 14:
		m_p2strResult="�׳˺��淢�ִ���";
		break;
	case 15:
		m_p2strResult="ɵ��, û��������ô����!";
		break;
	default:
		m_p2strResult="����δ�������, �������ʽ";
	}
}
void CExampleDlg::top2Result()//need
{
	UpdateData(TRUE);
	if(m_p2strInput=="Program Writer" && m_bOneEquation && m_bOneMatrix)
	{
		Ball();
		return;
	}
	string expression="";
	int status=0;
	long double b;
	ostringstream oss;
	for(int i=0; i<m_p2strInput.GetLength(); i++)
	{
		expression=expression+m_p2strInput.GetAt(i);
	}
	eraser_space(expression);
	toLower(expression);
	status =  check_normal_expression( expression );
	if (status)
	{
		b = GetResult( status, expression );
		if (status)
		{
			m_p2strResult.Empty();
			oss<<(setprecision(15))<<b;
			expression=oss.str();
			for(int i=0; i<expression.length();i++)
			{
				m_p2strResult+=expression.at(i);
			}
		}
		else//�ڼ����г��ִ���
		{
			m_p2strResult="���ֲ��ɼ�����������ĸΪ 0 ���� tan90 ֮��";
		}
	}
	else if (expression=="")//����ʽ�������Ǵ����;
		m_p2strResult="ɵ��, û��������ô����!";
	else 
		Set_Error(wk);
	wk=0;
	UpdateData(FALSE);
}
string CExampleDlg::cs2s(CString& weeCS)
{
	string temps="";
	for (int i=0; i<weeCS.GetLength(); i++)
	{
		temps+=weeCS.GetAt(i);
	}
	return temps;
}
CString CExampleDlg::s2cs(string& weeS)
{
	CString tempcs="";
	for (int i=0; i<weeS.length(); i++)
	{
		tempcs+=weeS.at(i);
	}
	return tempcs;

}
string CExampleDlg::to_matrix_form(string s, int li, int co)
{
	if(s.at(0)!='[')
		return s;
	eraser_space(s);
	s.replace(0,1,"");
	s.replace(s.length()-1, 1, "");
	int x=s.find(",");
	while(x<string::npos)
	{
		s.replace(x, 1, "\t");
		x=s.find(",", x+1);
	}
	x=s.find(";");
	while(x<string::npos)
	{
		s.replace(x, 1, "\r\n");
		x=s.find(";", x+1);
	}
	return s;
}
void CExampleDlg::ShowM1()
{
	UpdateData(TRUE);
	string st=cs2s(m_p3strM1);
	int a1, a2;
	int stat=check_matrix(st, a1, a2);
	if(stat!=0)
	{
		istringstream iss(st);
		ostringstream oss;
		oss<<"M1=\r\n";
		double dt;
		for(int i=0; i<a1; i++)
		{
			for(int j=0; j<a2; j++)
			{
				iss>>dt;
				oss<<dt;
				if(j!=a2-1)
					oss<<"\t";
			}
			oss<<"\r\n";
		}
		m_p3strResult=s2cs(oss.str());
	}
	else
		Set_Merror(mk);
	mk=0;
	UpdateData(FALSE);

}

void CExampleDlg::ShowM2()
{
	UpdateData(TRUE);
	string st=cs2s(m_p3strM2);
	int a1, a2;
	int stat=check_matrix(st, a1, a2);
	if(stat!=0)
	{
		istringstream iss(st);
		ostringstream oss;
		oss<<"M2=\r\n";
		double dt;
		for(int i=0; i<a1; i++)
		{
			for(int j=0; j<a2; j++)
			{
				iss>>dt;
				oss<<dt;
				if(j!=a2-1)
					oss<<"\t";
			}
			oss<<"\r\n";
		}
		m_p3strResult=s2cs(oss.str());
	}
	else 
		Set_Merror(mk);
	mk=0;
	UpdateData(FALSE);		

}
void CExampleDlg::toMResult()//need
{
	UpdateData(TRUE);
	int statu=0;
	string ms3;
	string ms1;
	string ms2;
	string Value;
	string Chara_Matrix;
	switch(Moptr)
	{
	case (OpMNone):
		m_p3strResult="δָ������,�޷�����";
		break;
	case (OpMAdd):
		ms1=cs2s(m_p3strM1);
		ms2=cs2s(m_p3strM2);
		toLower(ms1);
		toLower(ms2);
		statu=matrix_add(ms1, ms2, ms3);
		//		m_p3strResult="�������";
		break;
	case (OpMSub):
		ms1=cs2s(m_p3strM1);
		ms2=cs2s(m_p3strM2);
		toLower(ms1);
		toLower(ms2);
		statu=matrix_sub(ms1, ms2, ms3);
		//		m_p3strResult="�������";
		break;
	case (OpMMul):
		ms1=cs2s(m_p3strM1);
		ms2=cs2s(m_p3strM2);
		toLower(ms1);
		toLower(ms2);
		statu=matrix_mul(ms1, ms2, ms3);
		//		m_p3strResult="�������";
		break;
	case (OpMInv):
		ms1=cs2s(m_p3strM1);
		toLower(ms1);
//		toLower(ms2);
		//		ms2=cs2s(m_p3strM2);
		statu=matrix_inv(ms1, ms3);
		//		m_p3strResult="��������";
		break;
	case (OpMChara):
		//m_p3strResult="����������";
		ms1=cs2s(m_p3strM1);
		toLower(ms1);
//		toLower(ms2);
		//		ms2=cs2s(m_p3strM2);
		statu=matrix_cbi(ms1,Value, Chara_Matrix);
		ms3="����ֵΪ: "+Value+"\r\n��Ӧ��������������Ϊ: "+Chara_Matrix;
		break;
	case (OpMdet):
		ms1=cs2s(m_p3strM1);
		toLower(ms1);
//		toLower(ms2);
		statu=matrix_det(ms1, ms3);
		break;
	case (OpMt):
		ms1=cs2s(m_p3strM1);
		toLower(ms1);
//		toLower(ms2);
		statu=matrix_t(ms1, ms3);
		break;
	}	
	if(statu)
	{
		matr=ms3;
		switch(Moptr)
		{
		case (OpMChara):
			m_p3strResult=s2cs(ms3);
		default:
			m_p3strResult="result=\r\n"+s2cs(to_matrix_form(ms3, 1,1));
		}
	}
	else
	{
		matr="";
		Set_Merror(mk);
	}
	mk=0;
	UpdateData(FALSE);
}

void CExampleDlg::toM1()
{
	UpdateData(TRUE);
	if(m_p3strResult.GetAt(0)=='r'&& matr.length()>0)
	{
		if(matr.at(0)=='[')
			m_p3strM1=s2cs(matr);
		else
			m_p3strResult="���ܴ�һ��ʵ��ת����һ������";
	}
	else 
		m_p3strResult="�޷�ת��, �����н��";
	UpdateData(FALSE);
}
void CExampleDlg::Set_EQerror(int w)//need
{
	switch(w)
	{
	case 1:
		m_p4strResult="�ڽⷽ������������з���δ�������";
		break;
	case 2:
		m_p4strResult="�������벻����Ҫ��";
		break;
	case 3:
		m_p4strResult="��һԪ�������Ĺ����з���δ�������";
		break;
	case 4:
		m_p4strResult="����ȱ�ٵȺŻ��ұ߲�Ϊ��";
		break;
	case 5:
		m_p4strResult="�����г��ַǷ��ַ�";
		break;
	case 6:
		m_p4strResult="������ȱ��ָ��";
		break;
	case 7:
		m_p4strResult="���ַǷ�ʹ�õ������";
		break;
	case 8:
		m_p4strResult="�����435";
		break;
	case 9:
		m_p4strResult="�����453";
		break;
	case 10:
		m_p4strResult="�����468";
		break;
	case 11:
		m_p4strResult="��ߴ�ϵ������Ϊ0";
		break;
	case 12:
		m_p4strResult="�ڿ��������з���δ�������";
		break;
	case 13:
		m_p4strResult="�����622";
		break;
	case 14:
		m_p4strResult="�����631";
		break;
	default:
		m_p4strResult="δ֪����938";
		break;
	}
}




void CExampleDlg::toEQResult()//need
{
	string w1="";
	string w2="";
	string w3="";
	int statu=0;
	UpdateData(TRUE);
	if(m_bOneEquation)
	{
		w1=cs2s(m_p4strE);
		toLower(w1);
		statu=get_expression_result(w3, w1);
		if(statu)
			m_p4strResult=s2cs(w3);
		else
			Set_EQerror(ck);
	}
	else
	{
		w1=cs2s(m_p4strMcoff);
		w2=cs2s(m_p4strMb);
		toLower(w1);
		toLower(w2);
		statu=cal_equations(w1, w2, w3);
		if(statu)
			m_p4strResult=s2cs(w3);
		else
			Set_EQerror(ck);
	}
	ck=0;
	UpdateData(FALSE);
}

//page 1 by wanghao
void CExampleDlg::p1_OnOperandInput(UINT nID)
{
	
	switch(p1_CorR)
	{
	case p1_Real:
	ASSERT(nID>=IDC_1 && nID<=IDC_0);
	if(m_p1_errorState != p1_ErrNone)
		return;
	/*if(m_p1_func != p1_FuncNone)
	{
		m_p1_func = p1_FuncNone;
		p1_Calculate();
	}*/

	if(!m_p1_bOperandAvail)
		m_p1_operand = 0;
	if(!m_p1_bCoff)
		m_p1_operand = m_p1_operand*10 + p1_translate(nID);
	else
	{
		m_p1_operand = m_p1_operand + p1_translate(nID)*m_p1_coff;
		m_p1_coff *= 0.1;
		m_p1_k++;
	}
	
	m_p1_bOperandAvail = TRUE;
	m_p1_Equal=1;
	
	p1_UpdateDisplay();
	break;
	case p1_Complex:
	m_p1_Cxyavalue = TRUE;
	m_p1_equal=TRUE;
    ASSERT(nID>=IDC_1 && nID<=IDC_0);

	if(m_p1_errorState != p1_ErrNone)
		return;
	/*if(m_p1_func != p1_FuncNone)
	{
		m_p1_func = p1_FuncNone;
		p1_Calculate();
	}*/

	if(!m_p1_bOperandAvail)
	m_p1_complex_operand =_T("");
	m_p1_complex_operand.AppendChar(p1_complex_translate(nID));
	m_p1_bOperandAvail = TRUE;
	m_p1_Cxyavalue = TRUE;
	m_p1_equal=TRUE;
	m_p1_Equal=1;
	p1_UpdateDisplay();
	break;
	default:break;
	}
	
	
}
int CExampleDlg::p1_translate(UINT nID)
{
	switch(nID)
	{
	case IDC_1 : return 1; break;
	case IDC_2 : return 2;	break;
	case IDC_3 : return 3;	break;
	case IDC_4 : return 4;	break;
	case IDC_5 : return 5;	break;
	case IDC_6 : return 6;	break;
	case IDC_7 : return 7;	break;
	case IDC_8 : return 8;	break;
	case IDC_9 : return 9;	break;
	case IDC_0 : return 0;	break;
	default: return 0;break;
	}
}

char CExampleDlg::p1_complex_translate(UINT nID)
{
	switch(nID)
	{
	case IDC_1 : return '1';	break;
	case IDC_2 : return '2';	break;
	case IDC_3 : return '3';	break;
	case IDC_4 : return '4';	break;
	case IDC_5 : return '5';	break;
	case IDC_6 : return '6';	break;
	case IDC_7 : return '7';	break;
	case IDC_8 : return '8';	break;
	case IDC_9 : return '9';	break;
	case IDC_0 : return '0';	break;
	default: return '0';break;
	}
}

//����
BOOL CExampleDlg::p1_Keyboard(LPCTSTR szButton)
{
	switch (szButton[0])
	{
	case 'c':
	case 'C':
		p1_OnClear();
		break;

	case '/':
		p1_OnDivid();
		break;
	case '+':
		p1_OnAdd();
		break;
	case '-':
		p1_OnMinus();
		break;
	case '*':
		p1_OnMultiply();
		break;
	case '=':
		p1_OnEqual();
		break;
	default:
		if (szButton[0] >= '0' && szButton[0] <= '9')
		{
			if (m_p1_errorState != p1_ErrNone)
		         return FALSE;

	        if (!m_p1_bOperandAvail)
		         m_p1_operand = 0;

	        m_p1_operand=m_operand*10+szButton[0] - '0';
	        m_p1_bOperandAvail=TRUE;
	        p1_UpdateDisplay();
		}
		else
			return FALSE;
		break;
	}
	return TRUE;
}

/*BOOL CExample::PreTranslateMessage(MSG* pMsg)
{
	if (m_p1_hAccel != NULL && TranslateAccelerator(m_hWnd, m_p1_hAccel, pMsg))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}*/

void CExampleDlg::p1_OnAdd()
{
	
	if(!m_p1_C)
	p1_Calculate();
	m_p1_C = 0;
	m_p1_operator = p1_OpAdd;
	m_p1_j=1;
	m_p1_angle=1;
}
void CExampleDlg::p1_OnMinus()
{
	if(!m_p1_C)
	p1_Calculate();

	m_p1_C = 0;
	m_p1_operator = p1_OpSubtract;
	m_p1_j=1;
	m_p1_angle=1;
}
void CExampleDlg::p1_OnDivid()
{
	if(!m_p1_C)
	p1_Calculate();
	m_p1_C = 0;
	m_p1_operator = p1_OpDivide;
	m_p1_j=1;
	m_p1_angle=1;
}
void CExampleDlg::p1_OnMultiply()
{
	if(!m_p1_C)
	p1_Calculate();
	m_p1_C = 0;
	m_p1_operator = p1_OpMultiply;
	m_p1_j=1;
	m_p1_angle=1;
}
void CExampleDlg::p1_OnEqual()
{
	m_p1_Equal=0;
	p1_Calculate();
	m_p1_operator = p1_OpNone;
	m_p1_j=1;
	m_p1_angle=1;
	m_p1_equal=FALSE;
	//m_p1_bCoff=0;
	//m_p1_k=1;
	
}
void CExampleDlg::p1_OnSign()
{
	switch(p1_CorR)
	{
	case p1_Real:
	m_p1_operand *= -1;
	if (!m_p1_bOperandAvail)
		m_p1_accum *= -1;
	break;
	case p1_Complex:
	if(m_p1_complex_operand=="")
	{
		if(m_p1_complex_accum==""){}
		else
		{
			if(m_p1_complex_accum.GetAt(0)!='-')
	{
		m_p1_complex_accum.Insert(0,_T("-"));
		//m_p1_sign *= -1;
	}
	else
	{
		m_p1_complex_accum.Delete(0,1);
		//m_p1_sign *= -1;
	}
		}
	}
	else 
	{
	if(m_p1_complex_operand.GetAt(0)!='-')
	{
		m_p1_complex_operand.Insert(0,_T("-"));
		//m_p1_sign *= -1;
	}
	else
	{
		m_p1_complex_operand.Delete(0,1);
		//m_p1_sign *= -1;
	}
	}
	break;
	default:break;
	}
	p1_UpdateDisplay();
}
void CExampleDlg::p1_OnPoint()
{
	if( m_p1_pow_poi==1||m_p1_sqr_poi==1)
	{}
	else
	{
	m_p1_bOperandAvail=TRUE;
	m_p1_bCoff = 1;
	if(m_p1_Point==1)
	{
		//m_p1_complex_operand.Append(_T("."));
		
		
		if(m_p1_complex_operand==""||(m_p1_complex_operand.GetAt(m_p1_complex_operand.GetLength()-1)>'9'
			||m_p1_complex_operand.GetAt(m_p1_complex_operand.GetLength()-1)<'0'))
			m_p1_complex_operand.Append("0.");
		else 
			m_p1_complex_operand.Append(".");
		//if(	p1_CorR==p1_Complex) 
			p1_UpdateDisplay();
	}
	}
	m_p1_Point=0;
	
}
void CExampleDlg::p1_OnClear()
{
	m_p1_operand = 0;
	m_p1_complex_operand = _T("");
	if(p1_CorR==p1_Complex)
	{
		if(m_p1_Equal == 0||m_p1_complex_accum=="0")
	{
		m_p1_complex_accum= _T("0");
		m_p1_accum=0;
		m_p1_Equal=1;
		m_p1_j = 0;
	}
	else
	m_p1_C=1;
	
	}
	else
	{
		if(m_p1_Equal == 0)
	{
		m_p1_complex_accum= _T("0");
		m_p1_accum=0;
		m_p1_Equal=1;
		m_p1_j = 0;
	}
	else
	m_p1_C=1;
	}
	m_p1_j = 1;
	m_p1_angle = 1;
	m_p1_operator=p1_OpNone;
	p1_UpdateDisplay();
	m_p1_Point=1;
	m_p1_bCoff = 0;
	m_p1_k=1;

}
void CExampleDlg::p1_OnAllClear()
{
	m_p1_operand = m_p1_accum=0;
	m_p1_complex_operand = m_p1_complex_accum= _T("");
	m_p1_complex_accum=_T("0");
	p1_UpdateDisplay();
	m_p1_j = 1;
	m_p1_angle = 1;
	m_p1_operator=p1_OpNone;
	m_p1_Point=1;
	m_p1_bCoff = 0;
	m_p1_k=1;
}

    

void CExampleDlg::p1_Calculate()
{
	switch(p1_CorR)
	{
	case p1_Real:
	if(m_p1_errorState != p1_ErrNone)
		return;
	if (m_p1_bOperandAvail)
	{
		if (m_p1_operator == p1_OpNone)
			m_p1_accum = m_p1_operand;
		else if (m_p1_operator == p1_OpMultiply)
			m_p1_accum *= m_p1_operand;
		else if (m_p1_operator == p1_OpDivide)
		{
			if(m_p1_operand == 0)
				m_p1_errorState = p1_ErrDivideByZero;
			else 
				m_p1_accum /= m_p1_operand;
		}
		else if (m_p1_operator == p1_OpAdd)
			m_p1_accum += m_p1_operand;
		else if (m_p1_operator == p1_OpSubtract)
			m_p1_accum -= m_p1_operand;
	}

	m_p1_bOperandAvail = FALSE;
	m_p1_bCoff = 0;
	m_p1_k=1;
	m_p1_coff = 0.1;
	m_p1_operand=0;
	break;
	case p1_Complex:
		{
	string operand="",accum="";
	accum = cs2s(m_p1_complex_accum);
	operand = cs2s(m_p1_complex_operand);
	if(m_p1_errorState != p1_ErrNone)
		return;
	if(accum=="0"&&operand!=""&&m_p1_operator==p1_OpNone)
	{accum = operand;}
	if(operand==""){}
	else if (m_p1_bOperandAvail)
	switch(m_p1_operator)
	{
		
	case p1_OpNone:if(operand!="") accum = operand;break;
	case p1_OpMultiply:com_mul(accum, operand, accum);break;
	case p1_OpDivide:
		if(m_p1_complex_operand == "0+j0" || m_p1_complex_operand == "0+j-0" || m_p1_complex_operand == "0")
		{m_p1_errorState = p1_ErrDivideByZero;}
		else 
			com_div(accum, operand, accum);break;
	case p1_OpAdd:com_add(accum, operand, accum);break;
	case p1_OpSubtract:com_sub(accum, operand, accum);break;
	case p1_OpPower:
		{
			
			istringstream sst(operand); 
			int n=0; 
			sst>>n;
			com_pow(accum, n, accum);
			m_p1_Point=1;
			break;
		}
	case p1_OpSqre:
		{
			GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_SHOW);
			
			istringstream sst(operand); 
			int n=0; 
			sst>>n;
			m_p1_sarray_accum = new string [n];
			com_trt(accum, n, m_p1_sarray_accum);
			m_p1_csarray_accum = new CString[n];
			for(int i=0;i<n;i++)
			{
				m_p1_csarray_accum[i]=s2cs(m_p1_sarray_accum[i]);
				m_p1_ComboBox.AddString(m_p1_csarray_accum[i]);

			}

			delete [] m_p1_sarray_accum;
			delete [] m_p1_csarray_accum;

			m_p1_Point=1;
			break;
		}
	default:break;
	}
	m_p1_complex_accum = s2cs(accum);
	m_p1_bOperandAvail = FALSE;
	m_p1_Cxyavalue=FALSE;
		}
	default:break;
	}
	p1_UpdateDisplay();
	m_p1_errorState = p1_ErrNone;
	m_p1_complex_operand = _T("");
	m_p1_Point=1;
	m_p1_j=m_p1_angle=0;//////////////?????????????
	m_p1_pow_poi=0;
	m_p1_sqr_poi=0;
	
	
}

void CExampleDlg::p1_UpdateDisplay()
{
	switch(p1_CorR)
	{
	case p1_Real:
	if(GetSafeHwnd() == NULL)
		return;
	if (m_p1_errorState != p1_ErrNone)
		m_p1_result="��������Ϊ��";
	else
	{
		double lVal = (m_p1_bOperandAvail) ? m_p1_operand : m_p1_accum;
		m_p1_result.Format(_T("%f"),lVal);
		//if(m_p1_operand==0)// || m_p1_operand<0)
		//{
		if(m_p1_bCoff == 0)
		{
		int i=m_p1_result.GetLength();
		{
			while (m_p1_result.GetAt(i-1) == '0')
			{
				m_p1_result.Delete(i-1,1);
				i -= 1;
			}
		}
		}
		if(m_p1_bCoff == 1)
		{
			int i=m_p1_result.GetLength();
		{
			while (m_p1_result.GetAt(i-1) == '0' && i > (m_p1_result.Find(_T("."))+m_p1_k))
			{
				m_p1_result.Delete(i-1,1);
				i -= 1;
			}
		}
		}
		//}
		//m_p1_bCoff == 0;
		//m_p1_k=1;
	}
	break;
	case p1_Complex:
		//

		if(GetSafeHwnd() == NULL)
		return;
		if (m_p1_errorState != p1_ErrNone)
		m_p1_result="��������Ϊ��";
		else{
			//AfxMessageBox("qqq");
		if(m_p1_complex_operand.Find(_T("+"))==0)
		m_p1_complex_operand.Insert(0,_T("0"));
		if(m_p1_complex_operand.Find(_T("*"))==0)
		m_p1_complex_operand.Insert(0,_T("1"));
		if(m_p1_complex_operand=="") {
			if(m_p1_complex_accum!="0") 
				m_p1_result=m_p1_complex_accum;
			else m_p1_result=_T("0."); }
		else if(m_p1_complex_operand != "") 
		{
			m_p1_result = (m_p1_bOperandAvail) ? m_p1_complex_operand : m_p1_complex_accum; 
		}
		if(m_p1_result.GetAt(0) =='0' && !(m_p1_result.GetAt(1) =='.'||m_p1_result.GetAt(1) =='+'||m_p1_result.GetAt(1) =='*'))
		{
			m_p1_complex_operand.Delete(0);m_p1_result=_T("0.");
		}
		//weeny added this
		if(m_p1_result.Find(_T("j0"))>0||
			m_p1_result.Find(_T("-0"))>0||
			m_p1_result.Find(_T("+0"))>0)
			//above
		{
		if(
			  (m_p1_result.Find(_T("j00"))>0||m_p1_result.Find(_T("j-00"))>0||m_p1_result.Find(_T("*/_+00"))>0||m_p1_result.Find(_T("*/_-00"))>0)
			||(m_p1_result.Find(_T("j01"))>0||m_p1_result.Find(_T("j-01"))>0||m_p1_result.Find(_T("*/_+01"))>0||m_p1_result.Find(_T("*/_-01"))>0)
			||(m_p1_result.Find(_T("j02"))>0||m_p1_result.Find(_T("j-02"))>0||m_p1_result.Find(_T("*/_+02"))>0||m_p1_result.Find(_T("*/_-02"))>0)
			||(m_p1_result.Find(_T("j03"))>0||m_p1_result.Find(_T("j-03"))>0||m_p1_result.Find(_T("*/_+03"))>0||m_p1_result.Find(_T("*/_-03"))>0)
			||(m_p1_result.Find(_T("j04"))>0||m_p1_result.Find(_T("j-04"))>0||m_p1_result.Find(_T("*/_+04"))>0||m_p1_result.Find(_T("*/_-04"))>0)
            ||(m_p1_result.Find(_T("j05"))>0||m_p1_result.Find(_T("j-05"))>0||m_p1_result.Find(_T("*/_+05"))>0||m_p1_result.Find(_T("*/_-05"))>0)
			||(m_p1_result.Find(_T("j06"))>0||m_p1_result.Find(_T("j-06"))>0||m_p1_result.Find(_T("*/_+06"))>0||m_p1_result.Find(_T("*/_-06"))>0)
			||(m_p1_result.Find(_T("j07"))>0||m_p1_result.Find(_T("j-07"))>0||m_p1_result.Find(_T("*/_+07"))>0||m_p1_result.Find(_T("*/_-07"))>0)
			||(m_p1_result.Find(_T("j08"))>0||m_p1_result.Find(_T("j-08"))>0||m_p1_result.Find(_T("*/_+08"))>0||m_p1_result.Find(_T("*/_-08"))>0)
			||(m_p1_result.Find(_T("j09"))>0||m_p1_result.Find(_T("j-09"))>0||m_p1_result.Find(_T("*/_+09"))>0||m_p1_result.Find(_T("*/_-09"))>0)
			)
		{m_p1_result.Delete(m_p1_result.GetLength()-1);
		m_p1_complex_operand.Delete(m_p1_complex_operand.GetLength()-1);}
		}
		if(m_p1_result=="0"||m_p1_result=="-0"||m_p1_result=="0+j0"||m_p1_result=="-0+j0"||m_p1_result=="0+j-0"||m_p1_result=="-0+j-0")
		{
			m_p1_result=_T("0.");}
		/*int i=m_p1_result.GetLength();
		{
			while (m_p1_result.GetAt(i-1) == '0')
			{
				m_p1_result.Delete(i-1,1);
				i -= 1;
			}
		}*/
		//if(m_p1_result="0")
			//m_p1_result=_T("0.");
		//if(2){int i=0;}
		//else if(m_p1_complex_operand == "") {m_p1_result=m_p1_complex_accum;} 
		}
	break;
	default:break;
	}

	UpdateData(FALSE);
	//m_p1_complex_operand = _T("");
}

void CExampleDlg::p1_OnJ()
{
	if(m_p1_complex_operand==""&&m_p1_complex_accum=="")
		m_p1_j=1;
	if(m_p1_complex_accum.Find(_T("+j-"))>0 && m_p1_complex_operand=="")
		m_p1_j=1;
	else if(m_p1_complex_accum.Find(_T("+j"))>0 && m_p1_complex_operand=="")
	m_p1_j=-1;
	if(m_p1_complex_operand.Find(_T("+j-"))>0)
		m_p1_j=1;
	else if(m_p1_complex_operand.Find(_T("+j"))>0 )
	{m_p1_j=-1;}
	if(m_p1_complex_operand.Find(_T("+j"))==-1 && ((m_p1_complex_accum.Find(_T("*/_"))>=0&&!m_p1_Cxyavalue)||m_p1_complex_operand.Find(_T("*/_"))>=0))
	{}
    else{
	//m_p1_bOperandAvail = TRUE;
	if( m_p1_j==1 || m_p1_j==-1) m_p1_angle=0;
	if(!m_p1_bOperandAvail)
		m_p1_complex_operand = _T("");
	if(m_p1_complex_operand != ""||(!m_p1_Cxyavalue && m_p1_equal)||m_p1_complex_accum=="0")
	{
	if( m_p1_j==1)
	{
		if(m_p1_complex_operand.Replace(_T("+j-"),_T("+j"))==1)
		{}
		else {
			m_p1_complex_operand.Append("+j");m_p1_Point=1;
		}
		m_p1_j=-1;
	}
	else if(m_p1_j==-1)
	{
		m_p1_complex_operand.Replace(_T("+j"),_T("+j-"));
		m_p1_j=1;
	}
	}
	else
	{
	if( m_p1_j==1)
	{
		if(m_p1_complex_accum.Replace(_T("+j-"),_T("+j"))==1)
		{}
		else 
			m_p1_complex_accum.Append("+j");
		m_p1_j=-1;
	}
	else if(m_p1_j==-1)
	{
		m_p1_complex_accum.Replace(_T("+j"),_T("+j-"));
		m_p1_j=1;
	}
	}
	}
	m_p1_bOperandAvail = TRUE;
	
	
	p1_UpdateDisplay();
}
void CExampleDlg::p1_OnAngle()
{
	if(m_p1_complex_operand==""&&m_p1_complex_accum=="")
		m_p1_angle=1;
	//if(m_p1_complex_accum.Find(_T("+j-"))>0 && m_p1_complex_operand=="")
	//	m_p1_j=1;
	//else if(m_p1_complex_accum.Find(_T("+j"))>0 && m_p1_complex_operand=="")
	//m_p1_j=-1;
	if(m_p1_complex_accum.Find(_T("*/_-"))>0 && m_p1_complex_operand=="")
		m_p1_angle=1;
	else if(m_p1_complex_accum.Find(_T("*/_+"))>0 && m_p1_complex_operand=="")
		m_p1_angle=-1;
	if(m_p1_complex_operand.Find(_T("*/_-"))>0)
		m_p1_angle=1;
	else if(m_p1_complex_operand.Find(_T("*/_+"))>0 )
		m_p1_angle=-1;
	//if(m_p1_complex_operand.Find(_T("*/_"))==-1)
	//{AfxMessageBox("***");}
	//
	if( m_p1_complex_operand.Find(_T("*/_"))==-1 &&((m_p1_complex_accum.Find(_T("+j"))>=0&&!m_p1_Cxyavalue)||m_p1_complex_operand.Find(_T("+j"))>=0))
	{}
		
	//AfxMessageBox("123");}
	else{
	//m_p1_bOperandAvail = TRUE;
	if( m_p1_angle==1 || m_p1_angle==-1) m_p1_j=0;
	if(!m_p1_bOperandAvail)
		m_p1_complex_operand = "";
	if(m_p1_complex_operand!=""||(!m_p1_Cxyavalue&&m_p1_equal)||m_p1_complex_accum=="0")
	{
	if( m_p1_angle==1)
	{
		if(m_p1_complex_operand.Replace(_T("*/_-"),_T("*/_+"))==1)
		{}
		else {m_p1_complex_operand.Append("*/_+");m_p1_Point=1;}
		m_p1_angle=-1;
	}
	else if( m_p1_angle==-1)
	{
		m_p1_complex_operand.Replace(_T("*/_+"),_T("*/_-"));
		m_p1_angle=1;
	}
	}
	else
	{
		if( m_p1_angle==1)
	{
		if(m_p1_complex_accum.Replace(_T("*/_-"),_T("*/_+"))==1)
		{}
		else m_p1_complex_accum.Append("*/_+");
		m_p1_angle=-1;
	}
	else if( m_p1_angle==-1)
	{
		m_p1_complex_accum.Replace(_T("*/_+"),_T("*/_-"));
		m_p1_angle=1;
	}
	}
	}

	m_p1_bOperandAvail = TRUE;
	
	p1_UpdateDisplay();
}
void CExampleDlg::p1_OnChange()
{
	string operand="",accum="";
	accum = cs2s(m_p1_complex_accum);
	operand = cs2s(m_p1_complex_operand);
	if(operand == "")
	com_change_form(accum, accum/*operand*/);
	else
	com_change_form(operand, operand);
	m_p1_complex_accum = s2cs(accum);
	m_p1_complex_operand = s2cs(operand);
	m_p1_bOperandAvail=TRUE;
	m_p1_j=1;
	m_p1_angle=1;
	p1_UpdateDisplay();
	
}
void CExampleDlg::p1_OnPower()
{
	
	m_p1_Point=0;
	
	if(!m_p1_C)
		p1_Calculate();
	m_p1_complex_operand=_T("");
	m_p1_C = 0;
	m_p1_operator = p1_OpPower;
	m_p1_j=0;
	m_p1_angle=0;
	m_p1_pow_poi=1;
	
}
void CExampleDlg::p1_OnSqre()
{
	m_p1_Point=0;
	if(!m_p1_C)
		p1_Calculate();
	m_p1_complex_operand=_T("");
	m_p1_C = 0;
	m_p1_operator = p1_OpSqre;
	m_p1_j=0;
	m_p1_angle=0;
	m_p1_sqr_poi=1;
	
	//new 
	/*GetDlgItem(IDC_EDIT1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_SHOW);
	CString a=_T("1232435");
	m_p1_ComboBox.AddString(a);*/

}

void CExampleDlg::p1_OnOKSqre()
{
	UpdateData(TRUE);
	int it=m_p1_ComboBox.FindString(0,m_p1_Combox1);
	if(it>=0&&it<m_p1_ComboBox.GetCount())
	{
	m_p1_complex_accum=m_p1_Combox1;
	m_p1_complex_operand=_T("");
	if(m_p1_complex_accum=="") m_p1_complex_accum=_T("0.");
	m_p1_result=m_p1_complex_accum;
	GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
	UpdateData(FALSE);
	m_p1_Combox1=_T("");
//	if(m_p1_ComboBox.GetCount()==4);
//	AfxMessageBox("FDSF");
	}
	else
	{
		m_p1_complex_accum=_T("0.");
		m_p1_result=m_p1_complex_accum;
		GetDlgItem(IDC_COMPLEX_COMBO1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CLOSECOMBO)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT1)->ShowWindow(SW_SHOW);
		UpdateData(FALSE);
		m_p1_Combox1=_T("");
	}
	int cot=m_p1_ComboBox.GetCount();
	
	for (int i=0;i<cot;i++)//m_p1_ComboBox.GetCount();i++)
		m_p1_ComboBox.DeleteString(0);
}

