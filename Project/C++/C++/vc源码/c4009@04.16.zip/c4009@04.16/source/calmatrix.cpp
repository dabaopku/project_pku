#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"


#include<iostream>
#include<string>
#include<sstream>

#include "stdlib.h"
#include "stdio.h"
#include "math.h"
#include "check.h"
#include "ProcExpr.h"
#include "calmatrix.h"

using namespace std;

int mk=0;
//mk=1, ���һ�����ȱ�ٷֺ�
//mk=2, �����197
//mk=3, �������в��Ϸ��ı���ʽ;
//mk=4, ����ʽ�����г��ֲ��ɼ�������
//mk=5, ���������С��һ��;
//mk=6, ����1�����������ھ���2�ĺ���
//mk=7, ���������,��������
//mk=8, �������������������
//mk=9, �����ǶԳƾ���
//mk=10,����ʲô��û��,�޷�����
void brmul(double a[], double b[],int m,int n,int k, double c[])
//������ɺ�����a������Ϊm������Ϊn��b������Ϊn������Ϊk�����뵽c��
{ int i,j,l,u;
for (i=0; i<=m-1; i++)
for (j=0; j<=k-1; j++)
{ u=i*k+j; c[u]=0.0;
for (l=0; l<=n-1; l++)
c[u]=c[u]+a[i*n+l]*b[l*k+j];
}
return;
}

int brinv(double a[],int n)
//���������棬����aΪ��ά�����ͷָ�루����ά��������nΪ����Ľ���
//�������Ϊ0��˵������Ϊ������������Ϊ0����a�б�����
{
	//	long double* a=&dm.dou[0][0];
	int *is,*js,i,j,k,l,u,v;
	double d,p;
	is=(int*)malloc(n*sizeof(int));
	js=(int*)malloc(n*sizeof(int));
	for (k=0; k<=n-1; k++)
	{ d=0.0;
	for (i=k; i<=n-1; i++)
		for (j=k; j<=n-1; j++)
		{ l=i*n+j; p=fabs(a[l]);
	if (p>d) { d=p; is[k]=i; js[k]=j;}
		}
		if (d+1.0==1.0)
		{ 
			free(is); free(js);
			return(0);
		}
		if (is[k]!=k)
			for (j=0; j<=n-1; j++)
			{ u=k*n+j; v=is[k]*n+j;
		p=a[u]; a[u]=a[v]; a[v]=p;
			}
			if (js[k]!=k)
				for (i=0; i<=n-1; i++)
				{ u=i*n+k; v=i*n+js[k];
			p=a[u]; a[u]=a[v]; a[v]=p;
				}
				l=k*n+k;
				a[l]=1.0/a[l];
				for (j=0; j<=n-1; j++)
					if (j!=k)
					{ u=k*n+j; a[u]=a[u]*a[l];}
					for (i=0; i<=n-1; i++)
						if (i!=k)
							for (j=0; j<=n-1; j++)
								if (j!=k)
								{ u=i*n+j;
					a[u]=a[u]-a[i*n+k]*a[k*n+j];
								}
								for (i=0; i<=n-1; i++)
									if (i!=k)
									{ u=i*n+k; a[u]=-a[u]*a[l];}
	}
	for (k=n-1; k>=0; k--)
	{ if (js[k]!=k)
	for (j=0; j<=n-1; j++)
	{ u=k*n+j; v=js[k]*n+j;
	p=a[u]; a[u]=a[v]; a[v]=p;
	}
	if (is[k]!=k)
		for (i=0; i<=n-1; i++)
		{ u=i*n+k; v=i*n+is[k];
	p=a[u]; a[u]=a[v]; a[v]=p;
		}
	}
	free(is); free(js);
	return(1);
}


int cjcbi(double a[],int n,double v[],double eps,int jt)
//����ʵ�Գƾ���a������ֵ������ʱ�ٶԽ�Ԫ��Ϊ����ֵ��
//nΪ����
//v��i�б���a[ii]�ĵ���������
//expΪ���㾫��
//jtΪ��������
//�������Ϊ0���ʾ�ڵ��������ڴﲻ������Ҫ��
//�����������ʾ�ﵽҪ����
{	int i,j,p,q,u,w,t,s,l;
double fm,cn,sn,omega,x,y,d;
l=1;
for (i=0; i<=n-1; i++)
{ v[i*n+i]=1.0;
for (j=0; j<=n-1; j++)
if (i!=j) v[i*n+j]=0.0;
}
while (1==1)
{ fm=0.0;
for (i=1; i<=n-1; i++)
for (j=0; j<=i-1; j++)
{ d=fabs(a[i*n+j]);
if ((i!=j)&&(d>fm))
{ fm=d; p=i; q=j;}
}
if (fm<eps)  return(1);
if (l>jt)  return(-1);
l=l+1;
u=p*n+q; w=p*n+p; t=q*n+p; s=q*n+q;
x=-a[u]; y=(a[s]-a[w])/2.0;
omega=x/sqrt(x*x+y*y);
if (y<0.0) omega=-omega;
sn=1.0+sqrt(1.0-omega*omega);
sn=omega/sqrt(2.0*sn);
cn=sqrt(1.0-sn*sn);
fm=a[w];
a[w]=fm*cn*cn+a[s]*sn*sn+a[u]*omega;
a[s]=fm*sn*sn+a[s]*cn*cn-a[u]*omega;
a[u]=0.0; a[t]=0.0;
for (j=0; j<=n-1; j++)
if ((j!=p)&&(j!=q))
{ u=p*n+j; w=q*n+j;
fm=a[u];
a[u]=fm*cn+a[w]*sn;
a[w]=-fm*sn+a[w]*cn;
}
for (i=0; i<=n-1; i++)
if ((i!=p)&&(i!=q))
{ u=i*n+p; w=i*n+q;
fm=a[u];
a[u]=fm*cn+a[w]*sn;
a[w]=-fm*sn+a[w]*cn;
}
for (i=0; i<=n-1; i++)
{ u=i*n+p; w=i*n+q;
fm=v[u];
v[u]=fm*cn+v[w]*sn;
v[w]=-fm*sn+v[w]*cn;
}
}
return(1);
}



//////////////////////////////////////////////////////////////////////////////
//                    DIY               /////////////////////////////////////

int check_matrix(string& target,int& row,int& line)
{
	eraser_space(target);
	if(target.length()<=2)
	{
		if(mk==0)
			mk=10;
		return 0;
	}
	if((target[0]!='[') || (target[target.length()-1]!=']'))
	{
		if(mk==0)
			mk=11;
		return 0;
	}
	if((target[0]=='[')&&(target[target.length()-1]==']')&&(target[target.length()-2]==';'))
	{
		target.replace(0,1,"");
	}
	else
	{
		if(mk==0)
			mk=1;
		return 0;
	}

	row = 0;
	line = -1;
	int line_temp = 0;
	int x = 0;
	x = target.find(';');
	target.replace(x,1," ");
	while(x<string::npos)
	{
		row++;
		line_temp = 0;
		for(int i=0 ;i<x ;i++)
		{
			if (target[i] == ',')
			{
				target[i] = ' ';
				line_temp++;
			}
		}
		if((line!=-1)&&(line!=line_temp))
		{
			if(mk==0)
				mk=2;//�����197
			return 0;
		}
		line = line_temp;
		target.replace(x,1," ");
		x = target.find(';',x+1);
	}
	line++;
	target.replace(target.length()-1,1,"");

	istringstream iss(target);
	ostringstream oss;
	//	target="";
	string temp;
	if (iss.good())
	{
		iss>>temp;
	}
	int sta=0;
	double dd=0.0;
	while (iss.good())
	{
		//		cout<<"CHECK--->"<<temp<<"<----"<<endl;
		sta=check_normal_expression(temp);
		if (sta==0)
		{
			if(mk==0)
				mk=3;//�������в��Ϸ��ı���ʽ;
			return 0;
		}
		else 
		{
			int stat=1;
			dd=GetResult(stat,temp);
			if (stat==0)
			{
				if(mk==0)
					mk=4;//����ʽ�����г��ֲ��ɼ�������
				return 0;
			}
			else 
				oss<<dd<<" ";
		}
		//		target=target+temp+" ";
		iss>>temp;
	}
	target=oss.str();
	return 1;
}


int matrix_add(string s1, string s2, string& s3)
{
	int a1, a2, b1, b2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	int sta2=check_matrix(s2, b1, b2);
	if(sta2==0)
		return 0;
	if (sta1 && sta2 && (a1==b1) && (a2==b2))
	{
		istringstream iss1(s1);
		istringstream iss2(s2);
		double d1, d2, d3;
		ostringstream oss;
		oss<<"[ ";
		for (int i=0;i<a1;i++ )
		{
			for (int j=0;j<a2 ;j++ )
			{
				iss1>>d1;
				iss2>>d2;
				d3=d1+d2;
				oss<<d3;
				if (j!=a2-1)
					oss<<" , ";
			}
			oss<<" ; ";		
		}
		oss<<"]";
		s3=oss.str();
		return 1;
	}
	else
	{
		if(mk==0)
			mk=5;
		return 0;
	}

}

int matrix_sub(string s1, string s2, string& s3)
{
	int a1, a2, b1, b2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	int sta2=check_matrix(s2, b1, b2);
	if(sta2==0)
		return 0;
	if (sta1 && sta2 && (a1==b1) && (a2==b2))
	{
		istringstream iss1(s1);
		istringstream iss2(s2);
		double d1, d2, d3;
		ostringstream oss;
		oss<<"[ ";
		for (int i=0;i<a1;i++ )
		{
			for (int j=0;j<a2 ;j++ )
			{
				iss1>>d1;
				iss2>>d2;
				d3=d1-d2;
				oss<<d3;
				if (j!=a2-1)
					oss<<" , ";
			}
			oss<<" ; ";		
		}
		oss<<"]";
		s3=oss.str();
		return 1;
	}
	else 
	{
		if(mk==0)
			mk=5;
		return 0;
	}
}


int matrix_mul(string s1, string s2, string& s3)
{
	int a1, a2, b1, b2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	int sta2=check_matrix(s2, b1, b2);
	if(sta2==0)
		return 0;

	if (sta1 && sta2 && (a2==b1))
	{
		double* d1=new double[a1*a2];
		double* d2=new double[b1*b2];
		double* d3=new double[a1*b2];

		istringstream iss1(s1);
		istringstream iss2(s2);
		for (int i=0;i<a1*a2 ;i++ )
		{
			iss1>>d1[i];
		}
		for (int i=0;i<b1*b2 ;i++ )
		{
			iss2>>d2[i];
		}
		brmul(d1, d2, a1, a2, b2, d3);
		ostringstream oss;
		oss<<"[ ";
		for (int i=0;i<a1;i++ )
		{
			for (int j=0;j<b2 ;j++ )
			{
				oss<<d3[i*a1+j];
				if (j!=b2-1)
					oss<<" , ";
			}
			oss<<" ; ";		
		}
		oss<<"]";
		s3=oss.str();
		delete[] d1;
		delete[] d2;
		delete[] d3;

		return 1;
	}
	else 
	{
		if(mk==0)
			mk=6;
		return 0;
	}
}

int matrix_inv(string s1, string& s2)
{
	int a1, a2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	if (sta1 && (a1==a2))
	{
		istringstream iss(s1);
		double* d1=new double[a1*a2];
		for (int i=0;i<a1*a2 ;i++ )
		{
			iss>>d1[i];
		}
		int sta2=brinv(d1, a1);
		if (sta2==0)
		{
			if(mk==0)
				mk=7;
			delete[] d1;
			return 0;
		}
		else 
		{
			//		cout<<"line 554"<<endl;
			ostringstream oss;
			oss<<"[ ";
			for (int i=0;i<a1;i++ )
			{
				for (int j=0;j<a2 ;j++ )
				{
					oss<<d1[i*a1+j];
					if (j!=a2-1)
						oss<<" , ";
				}
				oss<<" ; ";		
			}
			oss<<"]";
			s2=oss.str();
			delete[] d1;
			return 1;
		}

	}
	else 
	{
		if(mk==0)
			mk=8;
		return 0;
	}
}

int matrix_cbi(string s1, string& s2, string& s3)
{
	int a1, a2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	if (sta1 && (a1==a2))
	{
		istringstream iss(s1);
		double* d1=new double[a1*a2];
		for (int i=0;i<a1*a2 ;i++ )
		{
			iss>>d1[i];
		}
		for (int i=0;i<a1 ;i++ )
		{
			for (int j=0;j<a2 ;j++ )
			{
				if (d1[i*a1+j]!=d1[j*a1+i])
				{
					delete[] d1;
					if(mk==0)
						mk=9;
					return 0;
				}
			}
		}
		double* d2=new double[a1*a2];
		int sta2=cjcbi(d1, a1, d2, 1e-6, 1000);
		if (sta2==0)
		{
			delete[] d1;
			delete[] d2;
			return 0;
		}
		else 
		{
			ostringstream oss1;
			ostringstream oss2;
			oss1<<"[ ";
			for (int i=0;i<a1 ;i++ )
			{
				oss1<<d1[i*a1+i]<<" ; ";
			}
			oss1<<"]";

			for (int i=0;i<a1 ;i++ )
			{
				oss2<<"[ ";
				for (int j=0;j<a2 ;j++ )
				{
					oss2<<d2[j*a1+i];
					oss2<<" ; ";
				}
				oss2<<"]";
				if (i!=a1-1)
					oss2<<" , ";
			}
			s2=oss1.str();
			s3=oss2.str();
			delete[] d1;
			delete[] d2;
			return 1;
		}

	}
	else 
	{
		if(mk==0)
			mk=8;
		return 0;
	}

}

//////////////////////////////////////////////////////////////////////////////
int exchangeLine(double** a,int i,int j,int n)
{
	int temp;
	for(int k=0;k<n;k++)
	{
		temp = a[i][k];
		a[i][k] = a[j][k];
		a[j][k] = temp;
	}
	return 1;
}

double cal_matrix_det(double* target,int n)
{
	double** a = new double*[n];
	for(int i=0;i<n;i++)
	{
		a[i] = new double[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		{
			a[i][j] = target[i*n+j];
		}

		int sign = 1;
		for(int i=0;i<n;i++)
		{
			if(a[i][i]==0)
			{
				if(i==n-1)
					return 0;
				else
				{
					int k = i+1;
					while((a[k][i]==0)&&(k<n-1))
					{
						k++;
					}
					sign = sign * (-1);
					exchangeLine(a,i,k,n);
				}
			}
			if(a[i][i]==0)
			{
				return 0;
			}
			else
			{
				for(int j=i+1;j<n;j++)
					for(int k=n-1;k>=i;k--)
					{
						//cout << i << j << k << " " << a[j][k] << endl;
						//cout << a[j][i]/a[i][i] << endl;
						a[j][k] = a[j][k] - a[i][k]*(a[j][i]/a[i][i]);
						//cout << i << j << k << " " << a[j][k] << endl;
					}
			}
		}

		double result = 1;
		for(int i=0;i<n;i++)
		{
			//		cout << "result = " << result << endl;
			//		cout << "i=" << i << endl;
			//		cout << "a[i][i]= " << result << endl;
			result = result * a[i][i];
		}
		for(int i=0;i<n;i++)
		{
			delete []a[i];
		}
		delete []a;


		return result*sign;
}

int matrix_det(string s1, string& s3)
{
	int a1, a2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	if (sta1 && (a1==a2))
	{
		istringstream iss(s1);
		double* d1=new double[a1*a2];
		for (int i=0;i<a1*a2 ;i++ )
		{
			iss>>d1[i];
		}
		double d=cal_matrix_det(&d1[0], a1);
		ostringstream oss1;
		oss1<<d;
		s3=oss1.str();
		return 1;
	}
	else 
		return 0;
}

int matrix_t(string s1, string& s3)
{
	int a1, a2;
	int sta1=check_matrix(s1, a1, a2);
	if(sta1==0)
		return 0;
	double** db=new double*[a1];
	for(int i=0; i<a1; i++)
	{
		db[i]=new double[a2];
	}
	istringstream iss(s1);
	for(int i=0; i<a1; i++)
	{
		for(int j=0; j<a2; j++)
			iss>>db[i][j];
	}	
	ostringstream oss;
	oss<<"[ ";
	for(int i=0; i<a2; i++)
	{
		for(int j=0; j<a1; j++)
		{
			oss<<db[j][i];
			if(j!=a1-1)
				oss<<" , ";
		}
		oss<<" ; ";
	}
	oss<<" ]";
	s3=oss.str();
	return 1;
}