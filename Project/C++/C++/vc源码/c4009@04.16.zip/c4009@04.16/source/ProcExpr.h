#include <iostream>
using namespace std;
#ifndef _PROCEXPR_H_
#define _PROCEXPR_H_
/*
struct Stack_Data;
typedef struct Stack_Data *PtrSData;
typedef PtrSData SData;

struct Stack_Op;
typedef struct Stack_Op *PtrSOp;
typedef PtrSOp SOp;

struct PPTable;
SData CreateSData(void); ///initialize stack for data
int Push_SData(long double const,SData);//push data into stack
long double Top_SData(SData const); //get top element of the data stack
int Pop_SData(SData); //pop an element out of the data stack
SOp CreateSOp(void); //initialize stack for operator
int Push_SOp(unsigned int const ,SOp); //push operator
char Top_SOp(SOp const);//get top operator
int Pop_SOp(SOp);//pop operator out
int IsEmpty_Op(SOp);//judge if stack is empty
int IsEmpty_Data(SData);//judge if stack is empty
int MakeEmpty_SData(SData);//make stack empty
int MakeEmpty_SOp(SOp);//ake stack empty
//unsigned int GetOpNum(char);//get operator num in optable , reserved
int GetPRI(char);//get PRI of an operator
int IfValidOperand(long double, long double, unsigned int const);//judge if the two operand is valid for specific operator
int PRICheck(char,char);//check PRI
long double BasicCalc(long double,long double,char *);//basic calculate
int ProcCalc(SData,SOp);//process stack to get a result 
int ProcPostfixOnline(long double *, SData, SOp ,string &,struct PPTable *);//kernel process for infix to postfix,return result
int DECConvert(__int64 *,char *,double *,int ,int ) ;
*/
long double GetResult(int &, string );
#endif