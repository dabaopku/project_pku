#include<iostream>
#include<string>
#include "check.h"
#include "ProcExpr.h"
#include "calmatrix.h"
#include "calcomplex.h"
using namespace std;
/*
int main()
{
//	string s="[0.2368,0.2471,0.2568,1.2671;1.1161,0.1254,0.1397,0.1490;0.1582,1.1675,0.1768,0.1871;0.1968,0.2071,1.2168,0.2271;]";
//	string s="[sin90, cos90; 1-1, 1!;]";
	string s="[2.0,-1.0,0.0; -1.0,2.0,-1.0; 0.0,-1.0,2.0;]";
//	string res;
	string s1, s2;
//	int st=matrix_inv(s, res);
	int st=matrix_cbi(s, s1, s2);
	cout<<s<<endl;
	cout<<s1<<endl;
	cout<<s2<<endl;
//	cout<<res<<endl;
//	cout<<"before"<<endl;
	return 0;
}

*/
/*
int main()
{
	string c1="1+j1";
	int m;
	double a,b;
	if (check_complex_form(c1,a,b,m))
	{
		cout<<"status= "<<1<<endl;
	}
	else cout<<"fuck"<<endl;
	complex co1(a, b, m);
	cout<<"line 20  "<<co1.to_string_xy_form()<<endl;
	complex* c3=new complex[3];
	if(ontrt(co1,3,c3))
	{
		for (int i=0;i<3 ;i++ )
		{
			cout<<c3[i].to_string_xy_form()<<endl;
			cout<<c3[i].to_string_angle_form()<<endl;
			cout<<endl;
		}
	}
	delete [] c3;
//	string c2="0+j0";
//	int m, n;
//	double a, b, c, d;
//	if(check_complex_form(c1, a, b, m))
//		cout<<1<<endl;
//	complex co1(a, b, m);
//	cout<<co1.to_string_xy_form()<<endl;
//	cout<<co1.to_string_angle_form()<<endl;
//	if(check_complex_form(c2, c, d, n))
//		cout<<1<<endl;
//	complex co2(c, d, n);
//	cout<<co2.to_string_xy_form()<<endl;
//	cout<<co2.to_string_angle_form()<<endl;
//	complex co3;
//	ocadd(co1.re, co1.im, co2.re, co2.im, &e, &f);
//	ocsub(co1.re, co1.im, co2.re, co2.im, &e, &f);
//	if(ocdiv(co1,co2,co3))
//	complex co3(e, f);
//	opowr(co1,2,co3);
//	{
//	cout<<co3.to_string_xy_form()<<endl;
//	cout<<co3.to_string_angle_form()<<endl;
//	}
	return 0;

}
*/



/*
int main()
{
//	string m1="[  cos 0 , tan 1 ; sin 9 0 , 3 ! ;]";
//	string m2="[1+2*(3),3*2;4+1,5-(1*21);]";
	string m1="[1,2,3;4,5,6;]";
	string m2="[1,2;3,4;5,6;]";
	int a1, a2, b1, b2;
	int sta1=check_matrix(m1, a1, a2);
	int sta2=check_matrix(m2, b1, b2);
//	cout<<"STA! "<<sta1<<"   STA2  "<<sta2<<endl;
	cout<<"M1:  "<<m1<<endl;
	cout<<"M2:  "<<m2<<endl;
	double_matrix dm3;
	double_matrix dm1(m1, a1, a2);
	cout<<dm1.to_string_form()<<endl;
	double_matrix dm2(m2, b1, b2);
	cout<<dm2.to_string_form()<<endl;
	string res;
	if (can_add_subt(dm1,dm2))//�ж��ܷ�Ӽ�
	{
	matrix_add(dm1,dm2,dm3);
	res=dm3.to_string_form();
	cout<<res<<endl;
	matrix_sub(dm1,dm2,dm3);
	res=dm3.to_string_form();
	cout<<res<<endl;
	}
	if (can_mutil(dm1,dm2))//�ж��ܷ����
	{
	matrix_mul(dm1,dm2,dm3);
	res=dm3.to_string_form();
	cout<<res<<endl;
	}
	return 0;
}
*/








void main()
{
	string expression= "1 +2+3+4+5+6";
	int status = 1;
	long double b = 0.00;

	while(1)
	{
		getline (cin, expression);
		eraser_space(expression);
		if ( expression == "quit" ) break;
		status =  check_normal_expression( expression );
		if (status)
		{
			b = GetResult( status, expression );
			if (status)
				printf("%10.15lf\n", b);
			else
				printf("ERROR!\n");
		}
		else
			printf("ERROR IN STRING!\n");
	}

}

/*
	string s[38]={
				"(2*(1+2^3^(2%6+(1+1)-2))) ",				
				"1.22!+(1+2)+2",
				"2(1+2)",
				"2.(1+2)",
				"(2+1.)2",
				"1==2",
				".123",
				"1+2.",
				"coscos2",
				"3!*s+sin2",
				"3!(.sin2)",
				"!sin2",
				"!3",
				"sin3!",
				"(123).123",
				"(sin3).123",
				"123.sin2",
				"sin4.",
				"3!.",
				"3!(10-1)",
				"sinsin2",
				"3.sin2",
				"3.(2)",
				"3!2",
				"--2",
				"cos2sin2",
				"!",					
				"cos+1",
				"3!(sin2)",
				"3!*sin2",
				"(1+2)(1+123)",
				"3..cos2",
				"ex1.2",
				"fuck",
				"atan5",
				"30sin1",
				"3!(-1)",
				"3!.12"
				};

/*	string s[50]={
"--34-5+d-3",
"10-5g-4*2",
"12.5.3+4",
"6/0.12.5",
"12-4+(5-(4-3)",
"43+5*(7-(8/2)))*2",
"3**2-3",
"6//3",
"6%%2",
"43-3^^2",
"2* /3",
"5+*5",
"2^/7",
".43+5*2",
"45+76.",
"334445345344-2",
"5556544765*(6434534522)",
"32.5-()+3",
"4-(9)*2",
"32++4",
"3--6",
"3+-5",
"2*+4",
"2^-6",
"$34-56d.678.4334",
"*43-..65-(+)43",
"43.+5++",
"2.3+54.4+4",
"234-5.3-43",
"2*4.4*2",
"4/2/2.00",
"3.4+66.77-7*87.5",
"42/3.455-34*3/2+1.23",
"32-7.54*54/5/6*4",
"4%2.0%1",
"2.0^3",
"2^2^2^2",
"2.3^0.30",
"3.5^0.2*2-11.11/45+6",
"0.4-3^1.0-7%4/5",
"(3+4-6)-(5-9.32)",
"32+(6-(76-7.43)*2-(125-2))",
"34.32+(65*6%3)-32/5.334-32",
"(6-32-(6^3/2/2*3)+232.23)-2",
"3.5-(76-7)+4.5^1-3",
"3-7.8+(2.3*2.3-(8%3))",
"54^(2-1-0.00)/1.00+4*654",
"43.45*6+(76-8/2*(65.76)-4%3)",
"0.87-54*3-5+8*(7676.65*(4/2))",
"2.322+34.6-7*65.5/4+565-43.332",};
*/