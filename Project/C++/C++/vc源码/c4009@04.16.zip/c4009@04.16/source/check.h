#ifndef CHECK_H
#define CHECK_H

#include<string>
using namespace std;

void eraser_space(string& s);//删除一个串中的所有空格
int check_dot_use(string& s);//检查和小数点有关的
int check_brackets(string& s);//检测括号配对情况, 正确返回1, 错误返回0
int check_invalid_char(string target); //检查非法字符 正确返回1, 错误返回0
int first_matched_bracket(string & s, int i);//寻找第一个配对的右括号，i是string中作括号的位置
int first_double(string & s, int i);//这个位置开始截取第一个double型量，i是开始数字的位置，返回最后一个数字在string中的位置
int change_func_form(string& s, int i,string name);//将单元运算符改成双元运算负，返回单元长度－1
string remove_bracket(string target); //去括号
string change_func_sign(string s); //把运算符和函数名都变成"A"
int is_number(char ch);//判断一个char是不是num，是的话返回1，不是则返回0
int make_op(string& target);//将target变成所要求的表达式
int check_invalid_operator(string& s);
//判断一个没有空格的只有数字小数点和A的串是不是合法
//包括1.2.3的情况和开头结尾不是double的情况
//然后中间一定是double和A交替出现
int check_invalid_links(string & s);//检查一员变二元会掩盖掉的问题



int check_normal_expression(string& s);//供bear调用
//输入string，判断是不是合法并且进行格式转换，得到标准的格式
//返回如果是1，则表达式合法


#endif
