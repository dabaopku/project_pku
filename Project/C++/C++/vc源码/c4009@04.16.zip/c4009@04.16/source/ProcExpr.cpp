//#include "stdafx.h"
#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <iostream>
#include <string>
#include <strstream>
#include <sstream>
#include <iso646.h>

#include <limits>
#include <float.h>
#include "check.h"
#include "ProcExpr.h"
#define SUCCESS 1
#define FAILURE 0
#define OVERFLOW 2
#define OpCount 31
#define FZero 10e-14
//#endif
using namespace std;

//
const long double pi = 3.14159265358979323846264338327950288419716939937510582097494459230;



struct Stack_Data;
typedef struct Stack_Data *PtrSData;
typedef PtrSData SData;
struct Stack_Data
{
	long double Data;
	SData Next;
};

struct Stack_Op;
typedef struct Stack_Op *PtrSOp;
typedef PtrSOp SOp;
struct Stack_Op
{
	char Op;
	SOp Next;
};
//////////////////////////////////////////////
/////Define Operator Table ///////////////////
struct OpTable
{
	char *opname;
	unsigned int opnum;
	int PRI;
}OperatorTable[]={
	{"&",0xe1,-79},
	{"|",0xe2,-79},
	{"d",0xe3,-50},//>=
	{"x",0xe4,-50},//<=
	{"X",0xeeb,-79},//XOR
	{"q",0xe5,-60},// ==
	{"n",0xe6,-60},//!=
	{">",0xe7,-50},
	{"<",0xe8,-50},
//	{"=",0xe9,-99},
	{"~",0xea,10},
	{"+",0xd0,1},
	{"-",0xd1,1},
	{"*",0xd2,2},
	{"/",0xd3,2},
	{"%",0xd4,2},
	{"#",0xd5,2},
	{"^",0xd6,3},
	{"p",0xd7,10},//exp()
	{"S",0xf0,10},//sin
	{"C",0xf1,10},//cos
	{"T",0xf2,10},//tan
//	{"A",0xf3,10},//ctan
	{"N",0xf4,10},//ln
	{"l",0xf5,10},//log
	{"f",0xf6,10},//factorial
	{"I",0xf7,10},//1/X
	{"s",0xf8,10},//arcsin
	{"c",0xf9,10},//arccos
	{"t",0xfa,10},//arctan
//	{"t",0xfb,10},//arcctan
	{"g",0xfc,10},//xlogy
	{"(",0xd6,98},
	{")",0xd7,98}
/*	{"B",0xd8,10},//DEC->BIN
	{"H",0xd9,10},//DEC->HEX
	{"O",0xda,10},//DEC->OCT
	{"b",0xdb,10},//BIN->DEC
	{"h",0xdd,10},//HEX->DEC
	{"o",0xdc,10} //OCT->DEC*/
	
};



///////////Define Public Proc Parameter Table///////////////
struct PPTable
{
	char lastread;
	int cread;
	char lasttype;
	long double readnum;
	char readop;
	unsigned long ptrExpr;

}ProcPTable={' ',0,' ',0.0,' ',0},*_PPTable=&ProcPTable;



////////////////Stack Operation////////////////
//////////////////////////////////////////////
////////////////Stack Data///////////////////
SData CreateSData(void)
{
	SData S;

	S =(SData) malloc( sizeof(struct Stack_Data) );
	if ( S == NULL )
		return FAILURE;
	S->Next = NULL;
	return S;
}

int Push_SData(long double const X,SData ptr_S)
{
	SData Tmp;

	Tmp=(SData)malloc(sizeof(struct Stack_Data));
	if( Tmp == NULL )
		return FAILURE;
	else
	{
		Tmp->Data = X;
		Tmp->Next = ptr_S->Next;
		ptr_S->Next = Tmp;
		return SUCCESS;
	}
}

long double Top_SData(SData const ptr_S)
{
	if( !(ptr_S->Next == NULL) )
	{
		return  ptr_S->Next->Data;
	}
}

int Pop_SData(SData ptr_S)
{
	SData Tmp;

	if( ptr_S->Next == NULL)
		return FAILURE;
	else
	{
		Tmp = ptr_S->Next;
		ptr_S->Next = ptr_S->Next->Next;
		free(Tmp);
		return SUCCESS;
	}
}
/////////////////////Stack Operator/////////
SOp CreateSOp(void)
{
	SOp S;

	S =(SOp) malloc( sizeof(struct Stack_Op) );
	if ( S == NULL )
		return FAILURE;
	S->Next = NULL;
	return S;
}

int Push_SOp(unsigned int const X,SOp ptr_S)
{
	SOp Tmp;

	Tmp=(SOp)malloc(sizeof(struct Stack_Op));
	if( Tmp == NULL )
		return FAILURE;
	else
	{
		Tmp->Op = X;
		Tmp->Next = ptr_S->Next;
		ptr_S->Next = Tmp;
		return SUCCESS;
	}
}

char Top_SOp(SOp const ptr_S)
{
	if( !(ptr_S->Next == NULL) )
		return ptr_S->Next->Op;
}

int Pop_SOp(SOp ptr_S)
{
	SOp Tmp;

	if( ptr_S->Next == NULL)
		return FAILURE;
	else
	{
		Tmp = ptr_S->Next;
		ptr_S ->Next = ptr_S->Next->Next;
		free(Tmp);
		return SUCCESS;
	}
}

int IsEmpty_Op(SOp S)
{
	return S->Next == NULL;
}
int IsEmpty_Data(SData S)
{
	return S->Next == NULL;
}

int MakeEmpty_SData(SData S)
{
	if ( S == NULL ) return FAILURE;
	while(!IsEmpty_Data(S))
		Pop_SData(S);
	return SUCCESS;
}

int MakeEmpty_SOp(SOp S)
{
	if ( S == NULL ) return FAILURE;
	while(!IsEmpty_Op(S))
		Pop_SOp(S);
	return SUCCESS;
}
/////////////////////////////////////////
////////////Parameters Check/////////////
int IfFloatZero( long double X )
{
	return  (fabs(X) <= FZero) ;
}
int isnan(long double x)
{
	return (!(x>=0) && !(x<0));
}
int DECConvert(__int64 *num,char *Buffer,double *dnum,int radix,int flag) 
{
	switch( flag)  
	{
	case 1:
		{//convert num->string
			if ( radix < 1 || radix > 36 ) return FAILURE; //radix out of range 2-36
			if ( Buffer == NULL ) return FAILURE; //No Buffer
			_i64toa( *num , Buffer , radix );
			return SUCCESS;
		}
	case 2://conver string->double
		{
			char *tmp = new char[strlen(Buffer)+2];
			char *stopstring;
			strcpy( tmp ,Buffer );
			strcat( tmp , "S" );

			*dnum = strtod( tmp, &stopstring );
			return	 SUCCESS;
		}
	case 3:
		{ //string -> num
			*num = _atoi64( Buffer );
			return SUCCESS;
		}
	default:return FAILURE;
	}
}
long double factorial(unsigned long X)
{
	long double S = 1;
	if ( X == 0 ) return 1;
	else
		for(;X>0;X--) S *= X;
	return S;
}
/*
unsigned int GetOpNum(char *opname)
{
	struct OpTable *_OpTable = &OperatorTable[0];
	for(int i=0;i<OpCount;i++){
		if( !strcmp(_OpTable->opname,opname) )
			return _OpTable->opnum;
		_OpTable++;
	}
	return 0xff;
}*/

int GetPRI(char op)
{
	int i;
	struct OpTable *_OpTable = &OperatorTable[0];
	for (i=0;i<OpCount;i++)
	{
		if ( (*_OpTable->opname == op) )
            return _OpTable->PRI;
		_OpTable++;
	}
	return FAILURE;
}
int IfValidOperand(long double pA, long double pB, char op)
{
	long double tmp;
	switch(op){
		case '/'://'/'
		case '%'://'%'
			{
				if ( IfFloatZero(pB) )
					return FAILURE;
			}break;
		case '^'://'^'
			{
				if(pA <= 0 && fabs(pB)<1) return FAILURE;

			}break;
		case 'c':
		case 's':			
				if((pA < -1 || pA >1 )) return FAILURE;
				break;
		case 'T':
			tmp = fmod (pA, 180);
			if( IfFloatZero(tmp)) return SUCCESS;  
			tmp = fmod (pA,90);
			if( IfFloatZero(tmp)) return FAILURE;
			break;
		case 'f':if( pA < 0 ) return FAILURE;
			break;
		case 'g':if ( pA <= 0 || pB <= 0 || pA == 1) return FAILURE;
			break;
		case 'l':if ( pA <= 0 ) return FAILURE;
			break;
		case 'I':if ( pA == 0) return FAILURE;
			break;
		case 'N':if ( pA <=0 ) return FAILURE;
			break;
		default:return SUCCESS;
	}
	return SUCCESS;
}

int PRICheck(char  funcname1, char  funcname2)
{
	int i = GetPRI(funcname1)-GetPRI(funcname2);

	if ( i > 0 ) return 1;
	if ( i < 0 ) return -1;
	if ( i == 0 ) return 0;
}


/* this function process each basic calculate */
long double BasicCalc(long double op_a, long double op_b, char *op)
{
	switch(*op){
		case '+':return op_a+op_b;/* operate ADD */
		case '-':return op_a-op_b;/* operate SUB */
		case '*':return op_a*op_b;/* operate MULTIPY */
		case '/':return op_a/op_b;/* operate DIVISION */
		case '%':return ((__int64)op_a)%((__int64)op_b);/* operate MOD */
		case '^':
			{
				if(op_b==0) return 1;			
				return pow(op_a,op_b);/* operate POW */
			}
		case '#':return fmod(op_a,op_b);//fmod
		case 'S':return sin(op_a/180.0*pi);//sin
		case 's':return asin(op_a);//arcsin
		case 'C':return cos(op_a/180.0*pi);//cos
		case 'c':return acos(op_a);//arccos
		case 'T':return tan(op_a/180.0*pi);//tan
		case 't':return atan(op_a); //arctan
		case 'f':return factorial(op_a);//�׳�
		case '<':return op_a < op_b;
		case '>':return op_a > op_b;
		case 'd':return op_a >= op_b;
		case 'x':return op_a <= op_b;
		case '&':return op_a && op_b;
		case '|':return op_a || op_b;
		case 'l':return log10( op_a );
		case 'a':return (__int64)op_a & (__int64)op_b;
		case 'o':return (__int64)op_a | (__int64)op_b;
		case 'g':return log10(op_b)/log10(op_a);
		case '~':return !op_a;
		case 'X':return (__int64)op_a^(__int64)op_b;
		case 'I':return 1.0/op_a;
		case 'n':return op_a != op_b;
		case 'q':return op_a == op_b;
		case 'N':return log(op_a);
		case 'p':return exp(op_a);
		
		default:return SUCCESS;
	}
}

/* this function process stack opeartion */
int ProcCalc(SData S_Data, SOp S_Op)
{

	long double tmp1,tmp2;
	char tmpop;
	int status = 0;

	if(IsEmpty_Op(S_Op)) return 1;
	tmpop=Top_SOp(S_Op);/* get operator */
	status=Pop_SOp(S_Op);/* pop operator */
	if(IsEmpty_Data(S_Data)) return 1;
	tmp1=Top_SData(S_Data);/* get operand 1*/
	Pop_SData(S_Data);/* pop operator 1*/


	if(IsEmpty_Data(S_Data)) return 1;
	tmp2=Top_SData(S_Data);/* get operator 2*/
	status=Pop_SData(S_Data);/* pop operator 2*/

	if(!IfValidOperand(tmp2,tmp1,tmpop)) return 1;/* invalid operands */
	tmp1=BasicCalc(tmp2,tmp1,&tmpop);/* calculate */
	Push_SData(tmp1,S_Data);/* push result back into stack*/
	return 0;/* successfully */
}


////////////////////////////////////////////////////////////////////////////////
/* this function process infix notation */
int ProcPostfixOnline(long double *result, SData S_Data, SOp S_Op,string &expression,struct PPTable *_PPTable)
{

	/* 0-initialized,1-num,2-op,3-left bracket,4-right bracket,5-end of line ,6-end of file,9-invalid data*/
	int GotType=0;/* store the type of got data */

	int PriChk=0;

	int leftbracket=0,rightbracket=0;
	/* TopLvlNum record such a state that:
	if it's time to read the first number in an express ,like -3+4.5
	or the number next to the left bracket, like (-4+3.2) */

	//int TopLvlNum=1;

	char tmpop;
	/* this flag set for detect what's need next */
	int NumNext = 1;
	/* convert postfix to infix and predigest it */
	long double num;char op;
	istringstream inputString(expression);
	//inputString.go
	
	_PPTable->lasttype='C';
	do
	{	
		//GotType=ReadInput(_PPTable,expression,NumNext);/* normal read */
		////////////////////////////////////
		inputString >> op;
		if (op == '(' )
		{
			_PPTable->readop = '(';
			_PPTable->lasttype = 'C';
			GotType = 2;
		}
		else
		{
			inputString.putback(op);

			if ( NumNext == 1)
			{
				inputString >> num;
				_PPTable->readnum = num;
				_PPTable->lasttype = 'N';
				GotType = 1;
			}
			else
			{
				inputString >> op;
				_PPTable->readop = op;
				_PPTable->lasttype = 'C';
				GotType = 2;
			}
		}
		///////////////////////////////////
			
		if(!inputString.good()) break;


		/////////////////////////////////
		if(GotType==1){
			//if(NumNext==0) return 1;/* operand needed, but got num */
			Push_SData(_PPTable->readnum,S_Data);/* push Operand into stack */
			_PPTable->lasttype='N';
			NumNext=0;
		}
		else
			if(GotType==2/*&&(GetPRI(_PPTable->readop,-99)!=-1)*/)
			{

				switch(_PPTable->readop){
					case '(':{
						if(_PPTable->lasttype=='N') return FAILURE;
						leftbracket++;/* leftbracket count */
						//TopLvlNum=1;/* set special flag for num read */
						NumNext=1;/* must be a number next */					
						Push_SOp(_PPTable->readop,S_Op);/* push '(' into stack */	
						_PPTable->lasttype='C';
						break;
							 }
					case ')':{
						rightbracket++;/* rightbracket count */
						//TopLvlNum=0;
						NumNext=0;/* must be a operator next */
						if(!IsEmpty_Op(S_Op)&&Top_SOp(S_Op)!='('){
							while(!IsEmpty_Op(S_Op)&&Top_SOp(S_Op)!='('){/* clear '(' */
								if(ProcCalc(S_Data,S_Op)) return FAILURE;
							}
							/* Pop '(' */
							if(!IsEmpty_Op(S_Op)) Pop_SOp(S_Op);
							else return 1;
						}
						else
							Pop_SOp(S_Op);/* '(' */			
						_PPTable->lasttype='N';
						break;
							 }
					default:{

						if(!IsEmpty_Op(S_Op))/* check stack status */
						{	

							tmpop=Top_SOp(S_Op);/* get the top operator in stack */
							if(NumNext==1) return FAILURE;/* num needed,but no num got,error */
							NumNext=1; /* must be a num next */
							PriChk=PRICheck(_PPTable->readop,tmpop);/* get pri check */
							if(PriChk==0&&tmpop!='^'){
								if(ProcCalc(S_Data,S_Op)) return FAILURE;
								Push_SOp(_PPTable->readop,S_Op);
								NumNext=1;
								_PPTable->lasttype='C';
								break;
							}

							if(PriChk<=0&&tmpop!='('&&((tmpop!=_PPTable->readop)&&_PPTable->readop!='^')){/*equal or lower pri ,'(' & '^' are special */
								if(tmpop=='^'){
									while(!IsEmpty_Op(S_Op)&& Top_SOp(S_Op)=='^'){
										if(ProcCalc(S_Data,S_Op)) return FAILURE;}	
									while(!IsEmpty_Op(S_Op)&&GetPRI(Top_SOp(S_Op))==2){
										if(ProcCalc(S_Data,S_Op)) return FAILURE;/* error found when calculate */
									}
									Push_SOp(_PPTable->readop,S_Op);
									_PPTable->lasttype='C';
									NumNext=1;
								}
								else
								{
									while(!IsEmpty_Op(S_Op)&& Top_SOp(S_Op)=='^'){
										if(ProcCalc(S_Data,S_Op)) return FAILURE;}
									while(!IsEmpty_Op(S_Op)&&((GetPRI(Top_SOp(S_Op))==2))||(GetPRI(Top_SOp(S_Op))==10)){
										if(ProcCalc(S_Data,S_Op)) return FAILURE;/* error found when calculate */
									}Push_SOp(_PPTable->readop,S_Op);/* push latest operator into stack */
									NumNext=1;
									_PPTable->lasttype='C';
								}
							}
							else
								if((GetPRI(_PPTable->readop)>=3) && (tmpop == '^')){
									Push_SOp(_PPTable->readop,S_Op);/* push latest operator into stack */
									NumNext=1;
									//TopLvlNum=0;	
									_PPTable->lasttype='C';
								}
								else
								{

									while(!IsEmpty_Op(S_Op)&& Top_SOp(S_Op)=='^'){
										if(ProcCalc(S_Data,S_Op)) return FAILURE;}
									/*while(!IsEmpty_Op(S_Op)&&GetPRI(Top_SOp(S_Op))==2){
									if(ProcCalc(S_Data,S_Op)) return 1;/* error found when calculate 
									}*/
									Push_SOp(_PPTable->readop,S_Op);/* push latest operator into stack */
									NumNext=1;
									//TopLvlNum=0;
									_PPTable->lasttype='C';
								}
						}
						else
						{ /* normal operator */
							if(PRICheck(_PPTable->readop,'^')==99) return FAILURE;
							Push_SOp(_PPTable->readop,S_Op);/* push operator into stack */
							NumNext=1;/* number needed in next input*/
							_PPTable->lasttype='C';
						}
							}
				}
			}
			else
				if(_PPTable->lastread==' ') ;/* space found ,omitted */
				else
					if(GotType==5) /* end of line ,jump out */
						return SUCCESS;
					else return FAILURE;/* other character, error */
	}while(inputString.good());


	if(leftbracket!=rightbracket) return FAILURE;/* brackets count check */

	while(!IsEmpty_Op(S_Op))/* calculate left elements in stack*/
		if(ProcCalc(S_Data,S_Op)) return FAILURE;	/* found error when calculating, return errcode */

	if(!IsEmpty_Data(S_Data)){/* if valid, return result */
		*result=Top_SData(S_Data);  
		
		if(isnan(*result)) return OVERFLOW;// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	}


	return SUCCESS;/* no error, pass */

}

long double GetResult(int &Status, string Expression)
{
/*	long double wee;
	istringstream iss(Expression);
	if(iss.good())
	{
		iss>>wee;
		if(!iss.good())
			return wee;
	}
*/
	SData S_Data = NULL;
	SOp S_Op = NULL;
	long double b = 0.0;

	S_Data = CreateSData();
	S_Op = CreateSOp();
	
	Expression = "(" + Expression + ")";
	Status = ProcPostfixOnline( &b, S_Data, S_Op, Expression, _PPTable);

	MakeEmpty_SData(S_Data);
	MakeEmpty_SOp(S_Op);
	free(S_Data);
	free(S_Op);	
	if (b>=-0.00000000001&&b<=0.00000000001)
		b=0;
	return b;
}
