// MakersDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Example.h"
#include "MakersDlg.h"
#include ".\makersdlg.h"
#include "ExampleDlg.h"


// CMakersDlg �Ի���

IMPLEMENT_DYNAMIC(CMakersDlg, CDialog)
CMakersDlg::CMakersDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMakersDlg::IDD, pParent)
{
}

CMakersDlg::~CMakersDlg()
{
}

void CMakersDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMakersDlg, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()

void CMakersDlg::ShowPhoto(CPaintDC* pdc, int a, int b)
{
	CExampleDlg* pWnd=(CExampleDlg*)GetParent();
	BITMAP bm;
	CDC dcMem;
	CRect rRect;

	pWnd->m_bmpBitmap.GetBitmap(&bm);
	dcMem.CreateCompatibleDC(pdc);
	dcMem.SelectObject(pWnd->m_bmpBitmap);
	GetClientRect(rRect);
	rRect.NormalizeRect();
//	pdc->StretchBlt(10,10, (rRect.Width()-20), (rRect.Height()-20), &dcMem, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);
	pdc->BitBlt(0,0, a, b, &dcMem, 0,0,/*bm.bmWidth, bm.bmHeight,*/ SRCCOPY);
}

// CMakersDlg ��Ϣ��������

void CMakersDlg::OnPaint()
{
	CRect rRect;
	GetClientRect(rRect);
	rRect.NormalizeRect();

	CPaintDC dc(this); // device context for painting
	CExampleDlg * pWnd=(CExampleDlg*)GetParent();
	if(pWnd)
	{
		ShowPhoto(&dc,rRect.Width(),rRect.Height());
	}
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
}
