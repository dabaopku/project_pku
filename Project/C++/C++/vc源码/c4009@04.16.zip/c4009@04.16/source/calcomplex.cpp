#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"


#include "math.h"
#include "calcomplex.h"
#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<iomanip>


using namespace std;


void ocmul(complex& a, complex& b, complex& c)
//���㸴���ĳ˷���a��jb��c��jd��ˣ����������e��f�У�����
//e,f�������ָ��
{
	double p,q,s;
	p=a.re*b.re; q=a.im*b.im; s=(a.re+a.im)*(b.re+b.im);
	c.re=p-q; c.im=s-p-q;
	return;
}

int ocdiv(complex& a, complex& b, complex& c)
//���㸴���ĳ�����a+jb / c+jd ���������e+jf��
//����e��f��ָ�����
{ double p,q,s,w;
p=a.re*b.re; q=-a.im*b.im; s=(a.re+a.im)*(b.re-b.im);
w=b.re*b.re+b.im*b.im;
if (w+1.0==1.0) 
{
	cout<<"��������Ϊ0"<<endl;
	return 0;
}
else
{ c.re=(p-q)/w; c.im=(s-p-q)/w; }
return 1;
}

int opowr(complex& a,int n,complex& c)
//����x��jy��n�η�
//���������u��v��
//u��v��ָ�������������

{ double r,q;
q=atan2(a.im,a.re);
r=sqrt(a.re*a.re+a.im*a.im);
/*if (a.re+1.0==1.0)
{
cout<<"��������Ϊ0"<<endl;
return 0;
}*/
if (r+1.0!=1.0)
{ r=n*log(r); r=exp(r);}
c.re=r*cos(n*q); c.im=r*sin(n*q);
return 1;
}


int ontrt(complex& a,int n,complex c[])
//������n�η���
//z��x+jy��ʾ��n��ʾ������Ҳ��u��v�Ĵ�С
//���������u��v��
{ int k;
double r,q,t;
if (n<1) return 0;
q=atan2(a.im,a.re);
r=sqrt(a.im*a.im+a.re*a.re);
if (a.re+1.0==1.0)
{
	cout<<"��������Ϊ0"<<endl;
	return 0;
}
if (r+1.0!=1.0)
{
	r=(1.0/n)*log(r); 
	r=exp(r);
}
//	cout<<"R  "<<r<<endl;
for (k=0; k<=n-1; k++)
{
	t=(2.0*k*3.1415926+q)/n;
	//		cout<<"T  "<<t<<endl;	
	c[k].re=r*cos(t);
	//		cout<<"line 79  "<<c[k].re<<endl;
	c[k].im=r*sin(t);
	//		cout<<"line 81  "<<c[k].im<<endl;
}
return 1;
}


///////////////////////////////////////////////////////////////////////////////////

void ocadd(complex& a, complex& b, complex& c)
{ 
	c.re=a.re+b.re;
	c.im=a.im+b.im;
	return;
}
void ocsub(complex& a, complex& b, complex& c)
{
	c.re=a.re-b.re;
	c.im=a.im-b.im;
	return;
}


int check_complex_form(string s, double& a, double& b,int& state)
//���complex��ʽ���������ɰ�ť���룬��˻����ϲ��жϺϷ���
//ֻ�Ǵ��ж�������double�������ٷ���һ�����������ֱ�������״̬��
{
	if(s.at(s.length()-1)=='j')
		s+="1";
	if(s.at(s.length()-1)=='-' && s.at(s.length()-2)=='j')
		s+="1";
	else if(s.at(s.length()-1)=='+' ||s.at(s.length()-1)=='-')
		s+="0";
	char ch;
	istringstream iss(s);
	iss>>a;
	iss>>ch;
	if (!iss.good())
	{
		b=0;
		state=1;
		return 1;
	}
	else
	{
		iss>>ch;
		switch (ch)
		{
		case ('j'):
			state=1;
			iss>>b;
			break;
		case ('/'):
			state=0;
			iss>>ch;
			if (ch!='_')
				return 0;
			iss>>b;
			break;	
		default:
			return 0;
		}
	}
	return 1;
}

string complex::to_string_angle_form()
{
	ostringstream oss;
	if (fabs(re)<0.0000001)
	{
		if (im>=0)
		{
			oss<<im<<"*/_+90";
		}
		else
		{
			double tim=-im;
			oss<<tim<<"*/_-90";
		}
	}
	else
	{
		double d=atan((double)im/re)*180/3.1415926536;
		if (re<0)
			d=d+180;
		if (d>=0)
		{
			oss<<setprecision(10)<<sqrt(re*re+im*im)<<"*/_+"<<d;
		}
		else 
			oss<<setprecision(10)<<sqrt(re*re+im*im)<<"*/_"<<d;
	}
	return oss.str();
}

string complex::to_string_xy_form()
{
	ostringstream oss;
	double tre=re;
	double tim=im;
	if (fabs(re)<1e-6)
	{
		tre=0;
	}
	if (fabs(im)<1e-6)
	{
		tim=0;
	}
	oss<<setprecision(10)<<tre<<"+j"<<setprecision(10)<<tim;
	return oss.str();
}

complex::complex(double RE_or_P, double IM_or_ANGLE, int status)
{
	if (status)
	{
		re	=RE_or_P;
		im	=IM_or_ANGLE;
	}
	else 
	{
		re	=RE_or_P*cos((double)IM_or_ANGLE*3.1415926536/180);
		im	=RE_or_P*sin((double)IM_or_ANGLE*3.1415926536/180);
	}
}

int com_add(string s1, string s2, string& s3)
{
	double a1, a2, b1, b2;
	int sta1, sta2;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		if(check_complex_form(s2, b1, b2, sta2))
		{
			complex comp2(b1, b2, sta2);
			complex comp3;
			ocadd(comp1, comp2, comp3);
			s3=comp3.to_string_xy_form();
		}
		else return 0;
	}
	else return 0;
	return 1;
}

int com_sub(string s1, string s2, string& s3)
{
	double a1, a2, b1, b2;
	int sta1, sta2;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		if(check_complex_form(s2, b1, b2, sta2))
		{
			complex comp2(b1, b2, sta2);
			complex comp3;
			ocsub(comp1, comp2, comp3);
			s3=comp3.to_string_xy_form();
		}
		else return 0;
	}
	else return 0;
	return 1;
}

int com_mul(string s1, string s2, string& s3)
{
	double a1, a2, b1, b2;
	int sta1, sta2;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		if(check_complex_form(s2, b1, b2, sta2))
		{
			complex comp2(b1, b2, sta2);
			complex comp3;
			ocmul(comp1, comp2, comp3);
			s3=comp3.to_string_xy_form();
		}
		else return 0;
	}
	else return 0;
	return 1;
}

int com_div(string s1, string s2, string& s3)
{
	double a1, a2, b1, b2;
	int sta1, sta2;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		if(check_complex_form(s2, b1, b2, sta2))
		{
			complex comp2(b1, b2, sta2);
			complex comp3;
			ocdiv(comp1, comp2, comp3);
			s3=comp3.to_string_xy_form();
		}
		else return 0;
	}
	else return 0;
	return 1;
}

int com_pow(string s1, int n, string& s3)
{
	double a1, a2;
	int sta1;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		complex comp3;
		opowr(comp1, n, comp3);
		s3=comp3.to_string_xy_form();
	}
	else return 0;
	return 1;
}

int com_trt(string s1, int n, string s3[])
{	
	double a1, a2;
	int sta1;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp1(a1, a2, sta1);
		complex* pComp=new complex[n];
		int sta2=ontrt(comp1 , n , pComp);
		if(sta2)
		{
			for(int i=0; i<n; i++)
				s3[i]=pComp[i].to_string_xy_form();
			delete[] pComp;
			return 1;
		}
		else
		{
			delete[] pComp;
			return 0;
		}
	}
	else 
		return 0;
}

int com_change_form(string s1, string& s3)
{
	double a1, a2;
	int sta1;
	if(check_complex_form(s1, a1, a2, sta1))
	{
		complex comp3(a1, a2, sta1);	
		if(sta1==1)
			s3=comp3.to_string_angle_form();
		else s3=comp3.to_string_xy_form();
	}
	else return 0;
	return 1;
}

