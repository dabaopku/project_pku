//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Example.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EXAMPLE_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     134
#define IDD_MAKERS                      134
#define IDI_ICON1                       136
#define IDI_ICON2                       137
#define IDB_BITMAP2                     138
#define IDC_TAB1                        1000
#define IDC_MCALC                       1003
#define IDC_BUTTON1                     1004
#define IDC_CALC                        1004
#define IDC_1                           1006
#define IDC_BUTTON3                     1006
#define IDC_2                           1007
#define IDC_3                           1008
#define IDC_4                           1009
#define IDC_5                           1010
#define IDC_6                           1011
#define IDC_7                           1012
#define IDC_8                           1013
#define IDC_9                           1014
#define IDC_0                           1015
#define IDC_POINT                       1016
#define IDC_EQUAL                       1017
#define IDC_ADD                         1018
#define IDC_SUB                         1019
#define IDC_MUL                         1020
#define IDC_DIV                         1021
#define IDC_sign                        1022
#define IDC_POWER                       1023
#define IDC_SQRE                        1024
#define IDC_SQRY                        1024
#define IDC_cXY                         1025
#define IDC_cANGLE                      1026
#define IDC_cFORM                       1027
#define IDC_C                           1028
#define IDC_AC                          1029
#define IDC_EDIT1                       1030
#define IDC_REAL                        1031
#define IDC_INPUT                       1032
#define IDC_RESULT                      1033
#define IDC_COMPLEX                     1034
#define IDC_STATIC2                     1035
#define IDC_STATIC3                     1036
#define IDC_M1                          1037
#define IDC_M2                          1038
#define IDC_MADD                        1039
#define IDC_MSUB                        1040
#define IDC_MMUL                        1041
#define IDC_CHARACTER                   1042
#define IDC_MINV                        1043
#define IDC_MT                          1044
#define IDC_MDET                        1045
#define IDC_STATIC7                     1046
#define IDC_MRESULT                     1047
#define IDC_MCOFF                       1048
#define IDC_MB                          1049
#define IDC_EXPRESSION                  1050
#define IDC_EQRESULT                    1051
#define IDC_EQCALC                      1052
#define IDC_STATIC8                     1053
#define IDC_STATIC9                     1054
#define IDC_STATIC10                    1055
#define IDC_STATIC11                    1056
#define IDC_FCHZU                       1057
#define IDC_HEL                         1058
#define IDC_EXIT                        1059
#define IDC_YIYUAN                      1060
#define IDC_STATIC5                     1062
#define IDC_STATIC6                     1063
#define IDC_BUTTON2                     1064
#define IDC_M1SHOW                      1064
#define IDC_M2SHOW                      1065
#define IDC_M_add                       1066
#define IDC_M_sub                       1067
#define IDC_M_mul                       1068
#define IDC_M_div                       1069
#define IDC_M_cha                       1070
#define IDC_BUTTON4                     1071
#define IDC_toM1                        1071
#define IDC_COMPLEX_COMBO1              1072
#define IDC_COMPLEX_COMBO2              1073
#define IDC_BUTTON5                     1074
#define IDC_CLOSECOMBO                  1074

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1075
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
